# Product Requirements Document (PRD)
## Local Servicing Marketplace Web Application

### 1. Project Overview
A modern, responsive location-aware marketplace connecting customers with local service providers for AC repair, electrical work, plumbing, vehicle servicing, appliance repair, cleaning, painting, carpentry, computer/mobile repair, RO/water purifier servicing, and other local services.

### 2. Project Vision
Make it easy for customers to discover, compare, book, communicate with, and review local service professionals while giving providers a practical system to manage services, availability, jobs, customers, earnings, and reviews.

### 3. Business Objective
Provide a two-sided local-services marketplace with customer booking, provider job management, online payments, communication, and administrator control.

### 4. Problem Statement
Customers need a convenient way to find suitable nearby professionals and manage service requests. Providers need a centralized way to present their services, receive requests, manage jobs, and track earnings.

### 5. Goals
- Location-aware provider discovery.
- Search and filtering by distance, price, rating, availability, and service type.
- Complete booking lifecycle.
- Secure customer/provider accounts.
- Provider onboarding and admin approval.
- Messaging, reviews, favorites, notifications, and payments.
- Real admin dashboard backed by Supabase data.
- Responsive, accessible, SEO-ready public website.

### 6. Non-Goals
- Do not invent a specific company identity, address, provider statistics, testimonials, partners, certifications, or revenue figures.
- Do not expose customer exact addresses publicly.
- Do not add integrations not required by the project.
- Exact payment gateway, map provider, notification provider, commission model, cancellation policy, and business rules are **To Be Decided**.

### 7. Target Users
1. Customers seeking local services.
2. Service providers/businesses offering local services.
3. Administrators operating the marketplace.

### 8. User Personas
**Customer:** Wants to find a nearby professional, compare options, book a suitable time, communicate, pay, and review the completed job.

**Service Provider:** Wants to create a credible business profile, define services and coverage, manage availability, accept jobs, communicate with customers, and monitor earnings.

**Administrator:** Needs operational visibility and control over users, providers, categories, services, bookings, payments, reviews, complaints, reports, analytics, and announcements.

### 9. User Roles
- Customer
- Service Provider
- Admin

RBAC must prevent users from accessing another role's protected functionality.

### 10. User Journeys
**Customer discovery:** Home → location/category → search → filters → provider profile → service selection.

**Customer booking:** Category → service → location → providers → provider/service → date/time → details/photos → estimate → booking → payment → booking status.

**Provider workflow:** Register → submit business/profile/documents → admin approval → configure services/areas/hours → receive request → accept/reject → perform job → update status → completion → earnings/review.

**Admin workflow:** Login → overview → manage users/providers/catalog/bookings/payments/reviews/complaints → analytics/reports → announcements/settings → logout.

### 11. User Stories
- As a customer, I want to select my locality so results are relevant.
- As a customer, I want to search and filter providers.
- As a customer, I want to inspect pricing, reviews, availability, and service details.
- As a customer, I want to request/book a service for a preferred time.
- As a customer, I want to upload photos describing the job.
- As a customer, I want to track, cancel, or reschedule my booking.
- As a customer, I want to chat with the provider.
- As a customer, I want to pay online and see payment history.
- As a customer, I want to favorite providers and review completed services.
- As a provider, I want to create and manage my business profile.
- As a provider, I want to define services, prices, service areas, and availability.
- As a provider, I want to accept/reject requests and update job status.
- As a provider, I want to see customers, messages, earnings, and reviews.
- As an admin, I want to approve/reject providers and manage marketplace data.
- As an admin, I want to moderate reviews and complaints and monitor payments/revenue.

### 12. Complete Website Structure
**Public:** Home, About, Services, Service Category Details, Search Results, Service Provider Profile, Login, Register, Forgot Password, Contact, FAQ, Privacy Policy, Terms & Conditions, Thank You, 404.

**Customer:** Dashboard, Find a Service, My Bookings, Booking Details, Messages, Favorites, Payments, Reviews, Notifications, Profile, Settings.

**Provider:** Dashboard, Service Requests, Upcoming Jobs, Active Jobs, Completed Jobs, Services & Pricing, Availability, Customers, Messages, Earnings, Reviews, Business Profile, Settings.

**Admin:** Overview, Users, Providers, Categories, Services, Bookings, Payments, Reviews, Complaints, Reports, Analytics, Settings.

### 13. Navigation Structure
Public header: logo/site identity (actual branding To Be Decided), Home, Services, About, FAQ, Contact, Search, Login/Register.

Authenticated users receive role-specific dashboard navigation. Admin routes are protected separately.

### 14. Page-by-Page Requirements
| Page | Requirements |
|---|---|
| Home | Hero, location selector, search, popular categories, popular services, nearby providers, top-rated professionals, how it works, why choose us, reviews, provider CTA, FAQ, footer |
| Services | Browse service categories and services |
| Category Details | Category description, services, filters/links to providers |
| Search Results | Location-aware provider/service results, filters, sorting, map |
| Provider Profile | Business info, services/pricing, service area, availability, reviews, photos, booking CTA |
| Booking Details | Booking information, status, messages/actions, payment information |
| Customer Dashboard | Current bookings, useful actions, notifications and account summary |
| Provider Dashboard | Requests, jobs, earnings and operational summary |
| Admin Overview | Real database-backed operational statistics |
| Contact | Contact/enquiry form |
| FAQ | Frequently asked questions |
| Auth pages | Secure login, registration and password reset |
| 404 | Helpful recovery navigation |
| Thank You | Confirmation after applicable successful submissions |

### 15. Functional Requirements
- Account registration/login/logout/password reset.
- Location selection and optional browser geolocation permission.
- Nearby provider discovery within configurable radius.
- Distance sorting and map visualization.
- Category/service search and filtering.
- Provider profiles and service catalogs.
- Booking creation, acceptance/rejection, status updates, cancellation/rescheduling.
- Photo upload attached to applicable booking requests.
- Online payment workflow.
- Customer/provider messaging.
- Favorites.
- Reviews/ratings for completed services.
- Notifications.
- Provider approval.
- Admin CRUD and moderation.
- Complaints/disputes.
- Analytics and reports.

### 16. Major Feature Requirements
For each feature, the implementation must define:
**Purpose, User, Inputs, Expected Behavior, Output, Acceptance Criteria.**

**Provider discovery**
- Purpose: find relevant local providers.
- User: Customer.
- Inputs: category/service, locality/location, filters.
- Behavior: query eligible providers and calculate/display distance.
- Output: result cards/list and map.
- Acceptance: results respect selected service area/radius and filters; customer exact address is never public.

**Booking**
- Purpose: create a service request.
- User: Customer.
- Inputs: service, provider, location, date/time, details, photos, estimate/payment information.
- Behavior: validate, persist booking, notify provider, show status.
- Output: booking record and confirmation.
- Acceptance: booking is stored in Supabase and status transitions are authorized.

**Provider job management**
- Purpose: manage requests and jobs.
- User: Provider.
- Inputs: accept/reject/status updates.
- Behavior: update authorized booking.
- Output: customer/admin see appropriate updated status.
- Acceptance: unauthorized providers cannot alter unrelated bookings.

**Payments**
- Purpose: collect online payments and record payment history.
- User: Customer/Provider/Admin as applicable.
- Inputs: booking and payment transaction data.
- Behavior: use a real payment integration selected during implementation.
- Output: transaction status and history.
- Acceptance: no card secrets are stored in the application database; exact gateway is To Be Decided.

**Messaging**
- Purpose: customer-provider communication.
- User: Customer/Provider.
- Inputs: message text and applicable attachments.
- Behavior: store/deliver messages only to booking participants.
- Output: conversation thread.
- Acceptance: access is restricted by authorization.

**Reviews**
- Purpose: capture completed-service feedback.
- User: Customer; Admin moderation.
- Inputs: rating/review.
- Behavior: permit review only for eligible completed booking.
- Output: moderated/displayable review.
- Acceptance: duplicate/ineligible reviews are prevented.

### 17. Forms and Fields
**Registration:** name, email, phone (if required), password, role, verification fields where required.

**Login:** email/identifier, password.

**Customer booking:** service, provider, locality/location, preferred date, preferred time, service details, photos, payment information as applicable.

**Provider onboarding/profile:** business name, contact information, description, service categories, service areas, photos, documents, services/prices, working hours.

**Contact:** name, email, phone if required, subject, message.

**Review:** rating, review text.

All forms use React Hook Form + Zod and server-side validation.

### 18. CTA Requirements
Primary CTAs include:
- Search Services
- Find a Service
- Book Service
- Contact Provider/Message
- Become a Service Provider
- Accept/Reject Request
- Pay Now where applicable
- Submit Review

### 19. Admin Requirements
Real protected application, not a mock UI. Admin must manage users, providers, categories, services, bookings, payments, reviews, complaints, reports, analytics, announcements/notifications, and account status.

### 20. Content Management
Admin-managed catalog and marketplace content should be stored in Supabase where dynamic. No hardcoded production records.

### 21. Search/Filter
Search by service/category/provider; filter by distance, price, rating, availability, and service type. Sorting includes distance and other relevant fields. Exact ranking formula is To Be Decided.

### 22. Authentication
Supabase Auth for registration, login, logout, password reset, secure sessions, and verification where required.

### 23. Authorization/RBAC
Role claims/profile data must determine access. Admin routes require admin authorization. Customers and providers may access only their own protected records and explicitly authorized shared records.

### 24. Database Requirements
Core tables:
- profiles
- provider_profiles
- service_categories
- services
- provider_services
- service_areas
- provider_availability
- bookings
- booking_attachments
- payments
- conversations
- messages
- favorites
- reviews
- notifications
- complaints
- announcements
- audit_logs

Exact payment and analytics implementation details are To Be Decided where business rules are missing.

### 25-44. SEO, Accessibility, Responsive, Performance, Security, States and Metadata
- Next.js Metadata API, sitemap.xml, robots.txt, Open Graph, canonical metadata and meaningful page titles/descriptions.
- Semantic HTML, keyboard navigation, visible focus, accessible labels, alt text, sufficient contrast and screen-reader support.
- Responsive mobile/tablet/desktop layouts; test navigation, forms, cards, tables, maps and admin UI at each breakpoint.
- Optimize images, lazy-load where appropriate, paginate large lists, minimize unnecessary client-side JavaScript and monitor production performance.
- Use HTTPS, environment variables, Supabase RLS, least privilege, validation/sanitization, protected admin routes, rate limiting, secure sessions, CSP, XSS/CSRF/injection protections, safe error messages and audit logging where applicable.
- Loading, empty, validation-error, server-error and success states must exist for all major asynchronous operations.
- Custom 404 and Thank You pages required.
- Privacy Policy, Terms & Conditions and cookie consent where applicable.
- Analytics must avoid exposing sensitive personal data.

### 45. Acceptance Criteria
The system is accepted when:
1. All specified public and role-specific pages work.
2. Customer discovery and booking work against real Supabase data.
3. Provider onboarding and approval work.
4. Provider job management works with authorization.
5. Messaging, favorites, reviews, notifications and payment records work through real implementation paths.
6. Admin CRUD/moderation works with real database data.
7. RLS and role restrictions are verified.
8. Forms validate on client and server.
9. Responsive/accessibility/security testing passes agreed criteria.
10. Production build succeeds without unresolved errors.

### 46. Success Metrics
Exact numeric targets are **To Be Decided**. Track, where applicable:
- Search-to-provider-profile conversion.
- Provider booking requests.
- Booking completion rate.
- Cancellation rate.
- Payment success rate.
- Provider approval turnaround.
- Customer/provider engagement.
- Review submission rate.
- Application performance and error rate.

### 47. Definition of Done
A feature is done only after implementation, immediate testing, error fixing, re-testing, regression verification, responsive verification, and required security/accessibility checks.

### 48. Final Product Checklist
- [ ] All required routes implemented.
- [ ] Real Supabase schema applied and verified.
- [ ] RLS/policies verified.
- [ ] Auth/RBAC verified.
- [ ] Real CRUD paths implemented.
- [ ] Booking lifecycle tested.
- [ ] Payment workflow verified with selected gateway.
- [ ] Messaging/reviews/notifications verified.
- [ ] Admin dashboard uses real data.
- [ ] Responsive/accessibility/security checks passed.
- [ ] SEO files and metadata verified.
- [ ] Error/loading/empty/success states verified.
- [ ] Production build and deployment verified.

## Continuous Development Rule
Use: **IMPLEMENT → RUN → TEST → IDENTIFY ERROR → FIX → RE-RUN → RE-TEST → VERIFY EXISTING FEATURES → CONTINUE**. Never accumulate known errors or postpone all testing until the end.
