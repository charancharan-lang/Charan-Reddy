# UI/UX Design Specification
## Local Servicing Marketplace Web Application

### 1. Design Philosophy
Professional, trustworthy, clear and conversion-oriented marketplace design. The interface should make finding a local service understandable within seconds while keeping booking and account management simple.

### 2. Brand Direction
No supplied logo, brand colors, font or reference website is specified. Brand identity is **To Be Decided**. Use a neutral, professional design token system that can be replaced through Tailwind/shadcn tokens without redesigning components.

### 3. Visual Style
Clean marketplace UI, strong hierarchy, rounded cards, clear service icons, practical data presentation, restrained motion, prominent search/location controls, and consistent status indicators.

### 4. Color System
Use semantic design tokens rather than hard-coded page-specific colors:
- Background / foreground
- Card / card foreground
- Primary / primary foreground
- Secondary / secondary foreground
- Muted / muted foreground
- Accent / accent foreground
- Border / input
- Destructive / destructive foreground
- Success / warning / informational status tokens

Exact brand palette: **To Be Decided**.

### 5. Typography
Use a highly legible sans-serif family compatible with the Next.js/Tailwind system. Exact brand font: **To Be Decided**.
- Display: strong weight.
- H1/H2: bold.
- H3: semibold.
- Body: regular.
- Labels/buttons: medium or semibold.

### 6. Font Sizes
Suggested responsive scale:
- Display: 40–56px desktop, 32–40px mobile
- H1: 36–48px
- H2: 28–36px
- H3: 20–24px
- Body: 16px
- Small/meta: 14px
- Caption: 12–13px

### 7. Font Weights
Regular 400, Medium 500, Semibold 600, Bold 700.

### 8. Spacing System
Use Tailwind spacing tokens consistently. Base spacing unit: 4px. Prefer 4/8/12/16/24/32/48/64px increments.

### 9. Border Radius
Use shadcn-compatible radius tokens. Medium rounding for controls; larger rounding for marketplace cards and hero surfaces.

### 10. Shadows
Use subtle elevation only where needed: cards, menus, dialogs and sticky controls. Avoid excessive shadows.

### 11. Buttons
Primary CTA for core actions; secondary for alternatives; outline/ghost for low-emphasis actions; destructive for cancellation/deactivation. Include visible focus and disabled states.

### 12. Cards
Provider cards show image/avatar, provider name, category/service, rating, distance, price indicator, availability and CTA. Service cards use icon/image, title and concise description.

### 13. Forms
Forms should be grouped into logical steps, use clear labels, inline validation, helper text and actionable errors. Avoid relying only on placeholders.

### 14. Inputs
Consistent height, focus ring, label association, error text and disabled styling. Location fields must clearly distinguish selected locality from private exact address.

### 15. Dropdowns
Use searchable/select controls where lists are large. Keyboard accessible and mobile-friendly.

### 16. Navigation
Public navigation is simple and search-oriented. Authenticated dashboards use a persistent sidebar on desktop and drawer/sheet navigation on mobile.

### 17. Header
Desktop: brand, navigation, search/location access, auth/account controls.
Mobile: compact header, menu, account access and optionally sticky primary CTA.

### 18. Footer
Service categories, navigation, provider CTA, FAQ/contact, legal links, and copyright/site information. No invented company information.

### 19. Hero Section
Headline: **Find Trusted Local Services Near You**
Subtitle: **Book reliable professionals for your home, vehicle, appliance, and everyday service needs.**
Include location selector, search field and **Search Services** CTA.

### 20. CTA Sections
Use prominent but non-intrusive CTAs for booking and provider onboarding. The provider CTA should use **Become a Service Provider**.

### 21. Page Layouts
Public pages use centered max-width content with consistent section spacing. Search uses list/filter/map layout. Profiles use summary + services + availability + reviews. Dashboards use sidebar + content area.

### 22. Section Layouts
Use clear headings, optional descriptions, responsive grids and consistent card dimensions. Avoid excessive dense content on mobile.

### 23. Mobile Layout
Single-column content, horizontally scrollable category chips where appropriate, stacked booking form, mobile filter drawer, compact cards, bottom/sticky CTA only where it improves booking conversion.

### 24. Tablet Layout
Two-column grids where practical, adaptive dashboard navigation, map/list split with comfortable touch targets.

### 25. Desktop Layout
Three/four-column category and provider grids where useful. Search results may use a list + map split. Admin uses data-dense tables with filters.

### 26. Responsive Breakpoints
Use Tailwind breakpoints: mobile base, `sm`, `md`, `lg`, `xl`, `2xl`. Exact component behavior must be tested at representative widths rather than assumed.

### 27. Components
- Header/Footer
- Search bar
- Location selector
- Category card
- Service card
- Provider card
- Rating display
- Filter panel
- Map panel
- Booking stepper
- Date/time selector
- File uploader
- Status badge
- Modal/dialog
- Toast/notification
- Tabs
- Tables
- Pagination
- Empty/error/loading states
- Dashboard sidebar
- Chat interface

### 28-35. Component States
Every interactive component must support default, hover, focus, active, disabled and loading states where relevant. Async content must provide skeleton/loading, empty and error states.

### 36. Animations
Use Framer Motion sparingly for page entrances, card transitions, dialogs and meaningful feedback. Respect reduced-motion preferences.

### 37. Page Transitions
Fast, subtle transitions. Never delay navigation or essential interaction.

### 38. Image Guidelines
Use optimized Supabase Storage images and Next.js image optimization. Define aspect ratios for provider photos, service images and thumbnails. Provide alt text and placeholders/fallbacks.

### 39. Icon Guidelines
Use Lucide React. Icons must support the label rather than replace understandable text. Keep icon sizing consistent.

### 40. Accessibility
WCAG-oriented implementation: semantic HTML, keyboard navigation, focus visibility, accessible form labels, error association, alt text, contrast, reduced motion and usable touch targets.

### 41. Visual Hierarchy
Primary task: search/book. Secondary tasks: compare provider information and communicate. Tertiary tasks: account settings and historical information.

### 42. Content Hierarchy
Use short headings, concise descriptions, clear service names, visible pricing information where supplied by provider, and transparent status labels.

### 43. CTA Placement
Primary CTA above the fold on Home and prominent on provider/service pages. Booking CTA remains visible at appropriate points in the booking flow.

### 44. Form UX
Use step-based booking where complexity warrants it: service → location → provider → date/time → details/photos → estimate → payment → confirmation.

### 45. Admin Dashboard UI
Professional data-management interface with overview cards, charts only when backed by real analytics data, searchable tables, filters, confirmation dialogs and clear destructive-action warnings.

### 46. Admin Tables
Responsive table-to-card behavior or horizontal scrolling as appropriate. Include pagination, loading, empty, error and action states.

### 47. Admin Forms
Consistent labels, validation, save/cancel actions, unsaved-change protection where needed, success/error feedback, and role-based visibility.

### Design Quality Rule
Do not create fake data, fake statistics or non-functional buttons. Every visible action must map to a documented implementation.
