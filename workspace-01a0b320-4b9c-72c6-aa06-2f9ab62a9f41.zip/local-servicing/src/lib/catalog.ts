import type { CatalogService, ServiceCategory } from "@/types"

/**
 * Marketplace taxonomy from the PRD. This is product catalog structure,
 * not live provider or booking records. Live catalog rows from Supabase
 * take precedence when the database is connected and populated.
 */
export const SEED_CATEGORIES: ServiceCategory[] = [
  {
    id: "cat-ac-repair",
    slug: "ac-repair",
    name: "AC Repair",
    description:
      "Installation, servicing, gas refill, and repair for split, window, and cassette air conditioners.",
    icon: "snowflake",
    sortOrder: 1,
  },
  {
    id: "cat-electrical",
    slug: "electrical",
    name: "Electrical",
    description:
      "Wiring, switches, lighting, fans, inverter work, and electrical safety repairs at home or work.",
    icon: "zap",
    sortOrder: 2,
  },
  {
    id: "cat-plumbing",
    slug: "plumbing",
    name: "Plumbing",
    description:
      "Leak repair, tap and pipe fitting, drainage, bathroom fittings, and water-supply issues.",
    icon: "droplets",
    sortOrder: 3,
  },
  {
    id: "cat-vehicle-servicing",
    slug: "vehicle-servicing",
    name: "Vehicle Servicing",
    description:
      "Periodic servicing, repairs, and maintenance for cars, bikes, and other local vehicles.",
    icon: "car",
    sortOrder: 4,
  },
  {
    id: "cat-appliance-repair",
    slug: "appliance-repair",
    name: "Appliance Repair",
    description:
      "Repair and maintenance for refrigerators, washing machines, microwaves, and other home appliances.",
    icon: "washing-machine",
    sortOrder: 5,
  },
  {
    id: "cat-cleaning",
    slug: "cleaning",
    name: "Cleaning",
    description:
      "Home, kitchen, bathroom, sofa, and deep-cleaning services for everyday and seasonal needs.",
    icon: "sparkles",
    sortOrder: 6,
  },
  {
    id: "cat-painting",
    slug: "painting",
    name: "Painting",
    description:
      "Interior and exterior painting, waterproofing touch-ups, and wall finishing.",
    icon: "paintbrush",
    sortOrder: 7,
  },
  {
    id: "cat-carpentry",
    slug: "carpentry",
    name: "Carpentry",
    description:
      "Furniture repair, fittings, doors, modular work, and custom woodwork.",
    icon: "hammer",
    sortOrder: 8,
  },
  {
    id: "cat-computer-mobile-repair",
    slug: "computer-mobile-repair",
    name: "Computer & Mobile Repair",
    description:
      "Laptop, desktop, and smartphone diagnostics, hardware repair, and software issues.",
    icon: "smartphone",
    sortOrder: 9,
  },
  {
    id: "cat-ro-water-purifier",
    slug: "ro-water-purifier",
    name: "RO & Water Purifier",
    description:
      "Installation, filter replacement, and servicing for RO and other water purifiers.",
    icon: "glass-water",
    sortOrder: 10,
  },
  {
    id: "cat-other-home-services",
    slug: "other-home-services",
    name: "Other Home Services",
    description:
      "Additional local home and everyday services that do not fit the categories above.",
    icon: "wrench",
    sortOrder: 11,
  },
]

export const SEED_SERVICES: CatalogService[] = [
  {
    id: "svc-ac-service",
    categorySlug: "ac-repair",
    slug: "ac-service",
    name: "AC servicing",
    description: "Routine cleaning and performance check for air conditioners.",
  },
  {
    id: "svc-ac-repair",
    categorySlug: "ac-repair",
    slug: "ac-repair-job",
    name: "AC repair",
    description: "Diagnosis and repair for cooling, noise, or leakage issues.",
  },
  {
    id: "svc-ac-install",
    categorySlug: "ac-repair",
    slug: "ac-installation",
    name: "AC installation",
    description: "New split or window AC installation and setup.",
  },
  {
    id: "svc-wiring",
    categorySlug: "electrical",
    slug: "wiring-repair",
    name: "Wiring repair",
    description: "Fault finding and repair for household electrical wiring.",
  },
  {
    id: "svc-switchboard",
    categorySlug: "electrical",
    slug: "switchboard-repair",
    name: "Switchboard repair",
    description: "Replacement or repair of switches, sockets, and boards.",
  },
  {
    id: "svc-fan-light",
    categorySlug: "electrical",
    slug: "fan-light-installation",
    name: "Fan & light installation",
    description: "Installation or replacement of fans, lights, and fittings.",
  },
  {
    id: "svc-leak",
    categorySlug: "plumbing",
    slug: "leak-repair",
    name: "Leak repair",
    description: "Fix leaking taps, pipes, and bathroom fittings.",
  },
  {
    id: "svc-clog",
    categorySlug: "plumbing",
    slug: "drain-unclogging",
    name: "Drain unclogging",
    description: "Clear blocked kitchen or bathroom drains.",
  },
  {
    id: "svc-tap",
    categorySlug: "plumbing",
    slug: "tap-fitting",
    name: "Tap & mixer fitting",
    description: "Install or replace taps, mixers, and shower fittings.",
  },
  {
    id: "svc-car-service",
    categorySlug: "vehicle-servicing",
    slug: "car-servicing",
    name: "Car servicing",
    description: "Periodic car service and inspection.",
  },
  {
    id: "svc-bike-service",
    categorySlug: "vehicle-servicing",
    slug: "bike-servicing",
    name: "Bike servicing",
    description: "Two-wheeler servicing and common repairs.",
  },
  {
    id: "svc-fridge",
    categorySlug: "appliance-repair",
    slug: "refrigerator-repair",
    name: "Refrigerator repair",
    description: "Cooling, noise, and component repair for refrigerators.",
  },
  {
    id: "svc-washer",
    categorySlug: "appliance-repair",
    slug: "washing-machine-repair",
    name: "Washing machine repair",
    description: "Diagnosis and repair for washers and dryers.",
  },
  {
    id: "svc-home-clean",
    categorySlug: "cleaning",
    slug: "home-cleaning",
    name: "Home cleaning",
    description: "Standard or deep cleaning for homes and apartments.",
  },
  {
    id: "svc-kitchen-clean",
    categorySlug: "cleaning",
    slug: "kitchen-bathroom-cleaning",
    name: "Kitchen & bathroom cleaning",
    description: "Focused cleaning for kitchens and bathrooms.",
  },
  {
    id: "svc-interior-paint",
    categorySlug: "painting",
    slug: "interior-painting",
    name: "Interior painting",
    description: "Room or full-home interior painting.",
  },
  {
    id: "svc-exterior-paint",
    categorySlug: "painting",
    slug: "exterior-painting",
    name: "Exterior painting",
    description: "Exterior wall painting and weatherproof finishing.",
  },
  {
    id: "svc-furniture",
    categorySlug: "carpentry",
    slug: "furniture-repair",
    name: "Furniture repair",
    description: "Repair and fitting for wooden furniture.",
  },
  {
    id: "svc-door",
    categorySlug: "carpentry",
    slug: "door-window-work",
    name: "Door & window work",
    description: "Repair or fitting of doors, windows, and frames.",
  },
  {
    id: "svc-laptop",
    categorySlug: "computer-mobile-repair",
    slug: "laptop-repair",
    name: "Laptop repair",
    description: "Hardware and software repair for laptops.",
  },
  {
    id: "svc-phone",
    categorySlug: "computer-mobile-repair",
    slug: "mobile-repair",
    name: "Mobile repair",
    description: "Smartphone screen, battery, and software repair.",
  },
  {
    id: "svc-ro-service",
    categorySlug: "ro-water-purifier",
    slug: "ro-servicing",
    name: "RO servicing",
    description: "Filter checks, cleaning, and performance service.",
  },
  {
    id: "svc-ro-filter",
    categorySlug: "ro-water-purifier",
    slug: "filter-replacement",
    name: "Filter replacement",
    description: "Replacement of RO and purifier filters.",
  },
  {
    id: "svc-handyman",
    categorySlug: "other-home-services",
    slug: "general-handyman",
    name: "General handyman",
    description: "Small home repairs and assembly work.",
  },
]

export const FAQS = [
  {
    question: "How do I find a service provider near me?",
    answer:
      "Select your locality, choose a service or category, and search. Results are limited to providers who serve that area. Your exact street address is never shown publicly.",
  },
  {
    question: "Do I need an account to book?",
    answer:
      "You can browse services without an account. Booking, messaging, payments, favorites, and reviews require a customer account.",
  },
  {
    question: "How does booking work?",
    answer:
      "Choose a service and provider, pick a preferred date and time, add job details and photos if needed, then submit the request. The provider accepts or declines, and you can track status from your bookings.",
  },
  {
    question: "Are providers verified?",
    answer:
      "Providers complete a business profile and document submission. An administrator reviews and approves providers before they can receive bookings.",
  },
  {
    question: "How are prices shown?",
    answer:
      "Providers set their own service prices. Where a starting price is available it is shown on search cards and profiles. Final charges can depend on the job details you share.",
  },
  {
    question: "Can I cancel or reschedule?",
    answer:
      "Yes. Open the booking and use cancel or reschedule while the booking is still eligible. Exact cancellation rules will follow the marketplace policy once it is finalized.",
  },
  {
    question: "How do payments work?",
    answer:
      "Online payment is part of the product. The payment gateway is still to be decided, so card charges are not collected until that integration is configured.",
  },
  {
    question: "How do reviews work?",
    answer:
      "After a booking is completed, the customer can leave a rating and review. Duplicate or ineligible reviews are blocked, and administrators can moderate published reviews.",
  },
  {
    question: "How do I become a service provider?",
    answer:
      "Register with a provider account, complete your business profile, add services, coverage areas, and availability, then submit for admin approval.",
  },
  {
    question: "Is my exact address public?",
    answer:
      "No. Search and profiles use locality or service area. Exact customer addresses stay private and are shared only as needed for an authorized booking.",
  },
] as const

export function getCategoryBySlug(slug: string) {
  return SEED_CATEGORIES.find((category) => category.slug === slug)
}

export function getServicesByCategory(slug: string) {
  return SEED_SERVICES.filter((service) => service.categorySlug === slug)
}

export function getServiceBySlug(slug: string) {
  return SEED_SERVICES.find((service) => service.slug === slug)
}
