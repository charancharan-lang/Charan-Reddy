"use server"

import { redirect } from "next/navigation"
import {
  forgotPasswordSchema,
  loginSchema,
  registerSchema,
  type ForgotPasswordInput,
  type LoginInput,
  type RegisterInput,
} from "@/lib/validations"
import { isSupabaseConfigured, siteConfig } from "@/lib/site"
import { createClient } from "@/lib/supabase/server"

export type ActionResult = { error: string } | { success: string }

export async function loginAction(input: LoginInput): Promise<ActionResult> {
  const parsed = loginSchema.safeParse(input)
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Check the form and try again." }
  }
  if (!isSupabaseConfigured()) {
    return { error: "Authentication is not available until Supabase is connected." }
  }

  const supabase = await createClient()
  const { error } = await supabase.auth.signInWithPassword({
    email: parsed.data.email,
    password: parsed.data.password,
  })
  if (error) return { error: error.message }

  redirect("/")
}

export async function registerAction(input: RegisterInput): Promise<ActionResult> {
  const parsed = registerSchema.safeParse(input)
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Check the form and try again." }
  }
  if (!isSupabaseConfigured()) {
    return { error: "Registration is not available until Supabase is connected." }
  }

  const supabase = await createClient()
  const origin = siteConfig.url
  const { error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      emailRedirectTo: `${origin}/login`,
      data: {
        full_name: parsed.data.name,
        phone: parsed.data.phone,
        role: parsed.data.role,
      },
    },
  })
  if (error) return { error: error.message }

  redirect("/thank-you?type=register")
}

export async function forgotPasswordAction(
  input: ForgotPasswordInput,
): Promise<ActionResult> {
  const parsed = forgotPasswordSchema.safeParse(input)
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Enter a valid email address." }
  }
  if (!isSupabaseConfigured()) {
    return { error: "Password reset is not available until Supabase is connected." }
  }

  const supabase = await createClient()
  const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${siteConfig.url}/login`,
  })
  if (error) return { error: error.message }

  redirect("/thank-you?type=reset")
}

export async function signOutAction() {
  if (!isSupabaseConfigured()) redirect("/")
  const supabase = await createClient()
  await supabase.auth.signOut()
  redirect("/")
}
