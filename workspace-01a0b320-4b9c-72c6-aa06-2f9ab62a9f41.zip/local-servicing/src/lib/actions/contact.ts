"use server"

import { redirect } from "next/navigation"
import { contactSchema, type ContactInput } from "@/lib/validations"
import { isSupabaseConfigured } from "@/lib/site"
import { createClient } from "@/lib/supabase/server"

export async function contactAction(input: ContactInput) {
  const parsed = contactSchema.safeParse(input)
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Check the form and try again." }
  }
  if (!isSupabaseConfigured()) {
    return { error: "The contact form is not available until the database is connected." }
  }

  const supabase = await createClient()
  const { error } = await supabase.from("contact_inquiries").insert({
    name: parsed.data.name,
    email: parsed.data.email,
    phone: parsed.data.phone || null,
    subject: parsed.data.subject,
    message: parsed.data.message,
  })
  if (error) {
    return { error: "Your message could not be saved. Please try again later." }
  }

  redirect("/thank-you?type=contact")
}
