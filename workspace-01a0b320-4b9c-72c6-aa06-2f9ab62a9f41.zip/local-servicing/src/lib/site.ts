export const siteConfig = {
  name: process.env.NEXT_PUBLIC_APP_NAME ?? "Local Services",
  url: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
  locale: process.env.NEXT_PUBLIC_LOCALE ?? "en-IN",
  currency: process.env.NEXT_PUBLIC_CURRENCY ?? "INR",
  tagline: "Find Trusted Local Services Near You",
  description:
    "Book reliable professionals for your home, vehicle, appliance, and everyday service needs.",
  mapProvider: process.env.NEXT_PUBLIC_MAP_PROVIDER ?? "none",
  paymentProvider: process.env.NEXT_PUBLIC_PAYMENT_PROVIDER ?? "none",
}

export const publicNav = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Services" },
  { href: "/about", label: "About" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact" },
] as const

export const legalNav = [
  { href: "/privacy", label: "Privacy Policy" },
  { href: "/terms", label: "Terms & Conditions" },
] as const

export const roles = ["customer", "provider", "admin"] as const
export type UserRole = (typeof roles)[number]

export function formatCurrency(amount: number) {
  try {
    return new Intl.NumberFormat(siteConfig.locale, {
      style: "currency",
      currency: siteConfig.currency,
      maximumFractionDigits: 0,
    }).format(amount)
  } catch {
    return `${amount}`
  }
}

export function formatDistance(km: number) {
  if (km < 1) return `${Math.round(km * 1000)} m`
  return `${km.toFixed(km < 10 ? 1 : 0)} km`
}

export function isSupabaseConfigured() {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  )
}
