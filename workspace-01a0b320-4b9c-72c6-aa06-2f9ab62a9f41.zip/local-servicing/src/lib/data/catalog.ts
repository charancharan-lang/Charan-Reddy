import { SEED_CATEGORIES, SEED_SERVICES, getCategoryBySlug } from "@/lib/catalog"
import { isSupabaseConfigured } from "@/lib/site"
import { createClient } from "@/lib/supabase/server"
import type { CatalogService, ServiceCategory } from "@/types"

export async function getCategories(): Promise<ServiceCategory[]> {
  if (isSupabaseConfigured()) {
    try {
      const supabase = await createClient()
      const { data, error } = await supabase
        .from("service_categories")
        .select("id, slug, name, description, icon, sort_order")
        .eq("is_active", true)
        .order("sort_order", { ascending: true })

      if (!error && data && data.length > 0) {
        return data.map((row) => ({
          id: row.id,
          slug: row.slug,
          name: row.name,
          description: row.description ?? "",
          icon: row.icon ?? "wrench",
          sortOrder: row.sort_order ?? 0,
        }))
      }
    } catch {
      // Fall back to seed taxonomy when the database is unreachable.
    }
  }

  return SEED_CATEGORIES
}

export async function getCategory(slug: string): Promise<ServiceCategory | undefined> {
  const categories = await getCategories()
  return categories.find((category) => category.slug === slug) ?? getCategoryBySlug(slug)
}

export async function getServices(categorySlug?: string): Promise<CatalogService[]> {
  if (isSupabaseConfigured()) {
    try {
      const supabase = await createClient()
      const { data, error } = await supabase
        .from("services")
        .select("id, slug, name, description, service_categories(slug)")
        .eq("is_active", true)
      if (!error && data && data.length > 0) {
        const mapped = data.map((row) => {
          const related = row.service_categories as { slug: string } | { slug: string }[] | null
          const relatedSlug = Array.isArray(related) ? related[0]?.slug : related?.slug
          return {
            id: row.id as string,
            slug: row.slug as string,
            name: row.name as string,
            description: (row.description as string) ?? "",
            categorySlug: relatedSlug ?? "",
          }
        })
        return categorySlug
          ? mapped.filter((service) => service.categorySlug === categorySlug)
          : mapped
      }
    } catch {
      // Fall back to seed taxonomy.
    }
  }

  return categorySlug
    ? SEED_SERVICES.filter((service) => service.categorySlug === categorySlug)
    : SEED_SERVICES
}

export type ProviderSearchRow = {
  id: string
  business_name: string
  short_bio: string | null
  rating_avg: number | null
  review_count: number | null
  logo_url: string | null
  status: string
  locality: string | null
}

export async function getProvidersForSearch(filters: {
  q?: string
  location?: string
  category?: string
  service?: string
}): Promise<ProviderSearchRow[]> {
  void filters
  if (!isSupabaseConfigured()) {
    return []
  }

  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from("provider_profiles")
      .select(
        "id, business_name, short_bio, rating_avg, review_count, logo_url, status, locality",
      )
      .eq("status", "approved")
      .limit(50)

    if (error || !data) return []
    return data as ProviderSearchRow[]
  } catch {
    return []
  }
}
