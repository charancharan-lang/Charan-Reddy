export type UserRole = "customer" | "provider" | "admin"

export type ProviderStatus = "pending" | "approved" | "rejected" | "suspended"

export type BookingStatus =
  | "pending"
  | "accepted"
  | "rejected"
  | "in_progress"
  | "completed"
  | "cancelled"
  | "rescheduled"

export type PaymentStatus = "pending" | "paid" | "failed" | "refunded"

export type ServiceCategory = {
  id: string
  slug: string
  name: string
  description: string
  icon: string
  sortOrder: number
}

export type CatalogService = {
  id: string
  categorySlug: string
  slug: string
  name: string
  description: string
}

export type ProviderCardData = {
  id: string
  businessName: string
  categoryName?: string | null
  rating?: number | null
  reviewCount?: number
  distanceKm?: number | null
  startingPrice?: number | null
  availableToday?: boolean | null
  imageUrl?: string | null
  locality?: string | null
  shortBio?: string | null
}

export type SearchFilters = {
  q?: string
  location?: string
  category?: string
  service?: string
  sort?: "distance" | "rating" | "price"
  radius?: string
  minRating?: string
  availability?: string
}

export type Locality = {
  label: string
  lat?: number
  lng?: number
  source: "typed" | "geolocation"
}
