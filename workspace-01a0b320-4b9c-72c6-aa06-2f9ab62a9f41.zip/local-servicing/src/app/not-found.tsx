import { PageHeader } from "@/components/marketplace/page-header"
import { ButtonLink } from "@/components/ui/button-link"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "Page not found",
  "This page does not exist. Return to search or browse services.",
  "/404",
)

export default function NotFound() {
  return (
    <>
      <PageHeader
        title="Page not found"
        description="The page you requested is not available. Use the links below to continue."
      />
      <div className="container-page flex flex-wrap gap-3 py-12">
        <ButtonLink href="/" size="xl">
          Go to home
        </ButtonLink>
        <ButtonLink href="/services" variant="outline" size="xl">
          Browse services
        </ButtonLink>
        <ButtonLink href="/search" variant="outline" size="xl">
          Search providers
        </ButtonLink>
        <ButtonLink href="/contact" variant="ghost" size="xl">
          Contact
        </ButtonLink>
      </div>
    </>
  )
}
