import type { MetadataRoute } from "next"
import { SEED_CATEGORIES } from "@/lib/catalog"
import { siteConfig } from "@/lib/site"

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date()
  const staticRoutes = [
    "",
    "/about",
    "/services",
    "/search",
    "/contact",
    "/faq",
    "/privacy",
    "/terms",
  ]

  return [
    ...staticRoutes.map((path) => ({
      url: `${siteConfig.url}${path}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: path === "" ? 1 : 0.7,
    })),
    ...SEED_CATEGORIES.map((category) => ({
      url: `${siteConfig.url}/services/${category.slug}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: 0.6,
    })),
  ]
}
