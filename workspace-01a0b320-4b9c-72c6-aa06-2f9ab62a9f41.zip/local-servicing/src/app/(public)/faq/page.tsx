import { PageHeader } from "@/components/marketplace/page-header"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { FAQS } from "@/lib/catalog"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "FAQ",
  "Answers about search, booking, provider approval, payments, and reviews.",
  "/faq",
)

export default function FaqPage() {
  return (
    <>
      <PageHeader
        title="Frequently asked questions"
        description="Practical answers about using the marketplace. Policies that are still to be decided are labelled as such."
      />
      <div className="container-page py-12">
        <Accordion className="rounded-2xl border bg-card px-4">
          {FAQS.map((item) => (
            <AccordionItem key={item.question} value={item.question}>
              <AccordionTrigger className="py-4 text-base">{item.question}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{item.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </>
  )
}
