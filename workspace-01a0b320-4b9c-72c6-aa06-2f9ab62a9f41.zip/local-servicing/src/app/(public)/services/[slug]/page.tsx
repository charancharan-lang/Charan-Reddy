import { notFound } from "next/navigation"
import { PageHeader } from "@/components/marketplace/page-header"
import { ServiceCard } from "@/components/marketplace/service-card"
import { ButtonLink } from "@/components/ui/button-link"
import { getCategories, getCategory, getServices } from "@/lib/data/catalog"
import { pageMetadata } from "@/lib/metadata"
import type { Metadata } from "next"

type Props = { params: Promise<{ slug: string }> }

export async function generateStaticParams() {
  const categories = await getCategories()
  return categories.map((category) => ({ slug: category.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const category = await getCategory(slug)
  if (!category) return pageMetadata("Category", "Service category", "/services")
  return pageMetadata(category.name, category.description, `/services/${category.slug}`)
}

export default async function CategoryPage({ params }: Props) {
  const { slug } = await params
  const category = await getCategory(slug)
  if (!category) notFound()
  const services = await getServices(category.slug)

  return (
    <>
      <PageHeader title={category.name} description={category.description} />
      <div className="container-page py-12">
        <div className="mb-8 flex flex-wrap gap-3">
          <ButtonLink href={`/search?category=${category.slug}`} size="lg">
            Find providers
          </ButtonLink>
          <ButtonLink href="/services" variant="outline" size="lg">
            All categories
          </ButtonLink>
        </div>
        <h2 className="mb-4">Services in this category</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
      </div>
    </>
  )
}
