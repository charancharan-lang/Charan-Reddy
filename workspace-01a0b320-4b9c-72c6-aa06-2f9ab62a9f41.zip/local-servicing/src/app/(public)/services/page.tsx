import { CategoryCard } from "@/components/marketplace/category-card"
import { PageHeader } from "@/components/marketplace/page-header"
import { getCategories } from "@/lib/data/catalog"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "Services",
  "Browse local service categories including AC repair, electrical, plumbing, cleaning, and more.",
  "/services",
)

export default async function ServicesPage() {
  const categories = await getCategories()

  return (
    <>
      <PageHeader
        title="Services"
        description="Choose a category to see related jobs and find providers who serve your locality."
      />
      <div className="container-page grid gap-4 py-12 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((category) => (
          <CategoryCard key={category.id} category={category} />
        ))}
      </div>
    </>
  )
}
