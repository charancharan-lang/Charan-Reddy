import Link from "next/link"
import { LoginForm } from "@/components/forms/login-form"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "Log in",
  "Sign in to manage bookings, messages, and your account.",
  "/login",
)

export default function LoginPage() {
  return (
    <div className="container-page flex justify-center py-12">
      <div className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-sm">
        <h1 className="text-2xl">Log in</h1>
        <p className="mt-2 mb-6 text-sm text-muted-foreground">
          Use the email and password for your customer, provider, or admin account.
        </p>
        <LoginForm />
        <p className="mt-6 text-sm text-muted-foreground">
          Need an account?{" "}
          <Link href="/register" className="font-medium text-primary hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  )
}
