"use client"

import { useState } from "react"
import { SlidersHorizontal } from "lucide-react"
import { EmptyState } from "@/components/marketplace/empty-state"
import { FilterPanel } from "@/components/marketplace/filter-panel"
import { MapPanel } from "@/components/marketplace/map-panel"
import { ProviderCard } from "@/components/marketplace/provider-card"
import { SearchBar } from "@/components/marketplace/search-bar"
import { Button } from "@/components/ui/button"
import { ButtonLink } from "@/components/ui/button-link"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import type { ProviderCardData } from "@/types"

export function SearchResults({
  query,
  location,
  category,
  providers,
}: {
  query?: string
  location?: string
  category?: string
  providers: ProviderCardData[]
}) {
  const [filtersOpen, setFiltersOpen] = useState(false)
  const summary = [query, category, location].filter(Boolean).join(" · ")

  return (
    <div className="container-wide py-8">
      <SearchBar defaultQuery={query} defaultCategory={category} variant="compact" />
      <div className="mt-6 mb-4 flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          {summary ? `Showing results for ${summary}` : "Showing all matching providers"}
        </p>
        <Button
          type="button"
          variant="outline"
          size="lg"
          className="lg:hidden"
          onClick={() => setFiltersOpen(true)}
        >
          <SlidersHorizontal className="size-4" />
          Filters
        </Button>
      </div>
      <div className="grid gap-6 lg:grid-cols-[16rem_1fr_18rem]">
        <aside className="hidden h-fit rounded-2xl border bg-card p-4 lg:block">
          <h2 className="mb-4 text-base font-semibold">Filters</h2>
          <FilterPanel />
        </aside>
        <div>
          {providers.length === 0 ? (
            <EmptyState
              title="No providers match this search"
              description="Approved providers who serve the selected locality and filters will appear here. There are no live provider records to display."
              action={
                <div className="flex flex-wrap justify-center gap-2">
                  <ButtonLink href="/services" variant="outline" size="lg">
                    Browse services
                  </ButtonLink>
                  <ButtonLink href="/register?role=provider" size="lg">
                    Become a Service Provider
                  </ButtonLink>
                </div>
              }
            />
          ) : (
            <div className="grid gap-4">
              {providers.map((provider) => (
                <ProviderCard key={provider.id} provider={provider} />
              ))}
            </div>
          )}
        </div>
        <MapPanel className="hidden lg:block" />
      </div>
      <div className="mt-6 lg:hidden">
        <MapPanel />
      </div>
      <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
        <SheetContent side="left">
          <SheetHeader>
            <SheetTitle>Filters</SheetTitle>
          </SheetHeader>
          <div className="px-4 pb-6">
            <FilterPanel />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
