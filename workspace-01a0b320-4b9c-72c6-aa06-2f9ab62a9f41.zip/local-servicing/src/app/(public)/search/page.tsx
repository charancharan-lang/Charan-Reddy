import { Suspense } from "react"
import { PageHeader } from "@/components/marketplace/page-header"
import { SearchResults } from "@/app/(public)/search/search-results"
import { getProvidersForSearch } from "@/lib/data/catalog"
import { pageMetadata } from "@/lib/metadata"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata = pageMetadata(
  "Search results",
  "Find local service providers by locality, category, distance, price, rating, and availability.",
  "/search",
)

type Props = {
  searchParams: Promise<{
    q?: string
    location?: string
    category?: string
    service?: string
  }>
}

export default async function SearchPage({ searchParams }: Props) {
  const params = await searchParams
  const rows = await getProvidersForSearch(params)
  const providers = rows.map((row) => ({
    id: row.id,
    businessName: row.business_name,
    shortBio: row.short_bio ?? undefined,
    rating: row.rating_avg,
    reviewCount: row.review_count ?? 0,
    imageUrl: row.logo_url,
    locality: row.locality,
  }))

  return (
    <>
      <PageHeader
        title="Search results"
        description="Location-aware provider results. Exact customer addresses are never shown publicly."
      />
      <Suspense
        fallback={
          <div className="container-page py-10">
            <Skeleton className="h-24 rounded-2xl" />
          </div>
        }
      >
        <SearchResults
          query={params.q}
          location={params.location}
          category={params.category}
          providers={providers}
        />
      </Suspense>
    </>
  )
}
