import { notFound } from "next/navigation"
import { EmptyState } from "@/components/marketplace/empty-state"
import { PageHeader } from "@/components/marketplace/page-header"
import { RatingDisplay } from "@/components/marketplace/rating"
import { ButtonLink } from "@/components/ui/button-link"
import { isSupabaseConfigured } from "@/lib/site"
import { createClient } from "@/lib/supabase/server"
import { pageMetadata } from "@/lib/metadata"
import type { Metadata } from "next"

type Props = { params: Promise<{ id: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params
  return pageMetadata("Service provider", "Provider profile and services.", `/providers/${id}`)
}

export default async function ProviderProfilePage({ params }: Props) {
  const { id } = await params

  if (!isSupabaseConfigured()) {
    return (
      <>
        <PageHeader
          title="Provider profile"
          description="Provider profiles are loaded from approved business records."
        />
        <div className="container-page py-12">
          <EmptyState
            title="Provider data is not connected"
            description="Connect Supabase to load live provider profiles. No sample businesses are shown."
            action={
              <ButtonLink href="/search" size="lg">
                Back to search
              </ButtonLink>
            }
          />
        </div>
      </>
    )
  }

  const supabase = await createClient()
  const { data: provider } = await supabase
    .from("provider_profiles")
    .select(
      "id, business_name, description, short_bio, locality, rating_avg, review_count, status",
    )
    .eq("id", id)
    .eq("status", "approved")
    .maybeSingle()

  if (!provider) notFound()

  const { data: services } = await supabase
    .from("provider_services")
    .select("id, price, price_unit, services(name, description)")
    .eq("provider_id", provider.id)
    .eq("is_active", true)

  const { data: reviews } = await supabase
    .from("reviews")
    .select("id, rating, body, created_at")
    .eq("provider_id", provider.id)
    .eq("is_published", true)
    .order("created_at", { ascending: false })
    .limit(20)

  return (
    <>
      <PageHeader
        title={provider.business_name}
        description={provider.short_bio ?? provider.description ?? "Approved service provider."}
      />
      <div className="container-page grid gap-8 py-12 lg:grid-cols-[1fr_18rem]">
        <div className="grid gap-8">
          <section>
            <div className="mb-3 flex flex-wrap items-center gap-3">
              <RatingDisplay rating={provider.rating_avg} count={provider.review_count} />
              {provider.locality ? (
                <p className="text-sm text-muted-foreground">Serves {provider.locality}</p>
              ) : null}
            </div>
            {provider.description ? (
              <p className="text-muted-foreground">{provider.description}</p>
            ) : null}
          </section>
          <section>
            <h2 className="mb-4">Services & pricing</h2>
            {services && services.length > 0 ? (
              <ul className="grid gap-3">
                {services.map((item) => {
                  const related = item.services as
                    | { name: string; description: string | null }
                    | { name: string; description: string | null }[]
                    | null
                  const service = Array.isArray(related) ? related[0] : related
                  return (
                    <li key={item.id} className="rounded-xl border bg-card p-4">
                      <p className="font-medium">{service?.name ?? "Service"}</p>
                      {service?.description ? (
                        <p className="text-sm text-muted-foreground">{service.description}</p>
                      ) : null}
                    </li>
                  )
                })}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">No services listed yet.</p>
            )}
          </section>
          <section>
            <h2 className="mb-4">Reviews</h2>
            {reviews && reviews.length > 0 ? (
              <ul className="grid gap-3">
                {reviews.map((review) => (
                  <li key={review.id} className="rounded-xl border bg-card p-4">
                    <RatingDisplay rating={review.rating} />
                    {review.body ? <p className="mt-2 text-sm">{review.body}</p> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">No published reviews yet.</p>
            )}
          </section>
        </div>
        <aside className="h-fit rounded-2xl border bg-card p-5" id="book">
          <h2 className="text-lg">Book this provider</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Booking requires a customer account. The request is stored and sent to the provider.
          </p>
          <ButtonLink href="/login" size="lg" className="mt-4 w-full">
            Book Service
          </ButtonLink>
          <ButtonLink href="/login" variant="outline" size="lg" className="mt-2 w-full">
            Message
          </ButtonLink>
        </aside>
      </div>
    </>
  )
}
