import { PageHeader } from "@/components/marketplace/page-header"
import { ButtonLink } from "@/components/ui/button-link"
import { pageMetadata } from "@/lib/metadata"
import { siteConfig } from "@/lib/site"

export const metadata = pageMetadata(
  "About",
  "Learn how this local servicing marketplace connects customers with nearby professionals.",
  "/about",
)

export default function AboutPage() {
  return (
    <>
      <PageHeader
        title="About"
        description={`${siteConfig.name} is a two-sided marketplace for discovering, comparing, booking, and reviewing local service professionals.`}
      />
      <div className="container-page grid gap-10 py-12 lg:grid-cols-[1.2fr_0.8fr]">
        <article className="prose prose-neutral max-w-none">
          <h2 className="mb-3">What this product does</h2>
          <p className="text-muted-foreground">
            Customers can select a locality, search by service, inspect provider profiles, request a
            booking, communicate about the job, and leave a review after the work is completed.
            Providers can present services, coverage, and availability, then manage incoming jobs.
            Administrators operate the catalog, approvals, and marketplace records.
          </p>
          <h2 className="mt-8 mb-3">Who it is for</h2>
          <ul className="list-disc space-y-2 pl-5 text-muted-foreground">
            <li>Customers who need nearby help for home, vehicle, appliance, and everyday jobs.</li>
            <li>Service providers who want a practical way to receive and manage local work.</li>
            <li>Administrators who need real operational control over the marketplace.</li>
          </ul>
          <h2 className="mt-8 mb-3">What we will not invent</h2>
          <p className="text-muted-foreground">
            Brand identity, office address, partner lists, certifications, revenue figures, and
            testimonials are not fabricated. Those details appear only when they exist in the
            product data.
          </p>
        </article>
        <aside className="grid h-fit gap-4 rounded-2xl border bg-card p-6">
          <h2 className="text-lg">Next step</h2>
          <p className="text-sm text-muted-foreground">
            Browse services or create an account to book and manage jobs.
          </p>
          <ButtonLink href="/services" size="lg">
            Browse services
          </ButtonLink>
          <ButtonLink href="/register" variant="outline" size="lg">
            Create an account
          </ButtonLink>
        </aside>
      </div>
    </>
  )
}
