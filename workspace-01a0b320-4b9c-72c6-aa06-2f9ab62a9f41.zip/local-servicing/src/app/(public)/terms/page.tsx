import { PageHeader } from "@/components/marketplace/page-header"
import { pageMetadata } from "@/lib/metadata"
import { siteConfig } from "@/lib/site"

export const metadata = pageMetadata(
  "Terms & Conditions",
  "Terms for using the local servicing marketplace as a customer or provider.",
  "/terms",
)

export default function TermsPage() {
  return (
    <>
      <PageHeader
        title="Terms & Conditions"
        description="These terms govern use of the marketplace. Commission, cancellation, and payment rules that are still to be decided are called out below."
      />
      <article className="container-page max-w-3xl space-y-6 py-12 text-muted-foreground">
        <p>Last updated: 18 September 2026.</p>
        <section>
          <h2 className="mb-2 text-foreground">1. The service</h2>
          <p>
            {siteConfig.name} is a marketplace that helps customers find local service providers and
            helps providers receive and manage jobs. The operator does not itself perform the
            underlying trade services unless separately agreed.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">2. Accounts</h2>
          <p>
            You must provide accurate registration details and keep credentials confidential.
            Customers, providers, and administrators have separate permissions. You may not access
            another role&apos;s protected functions.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">3. Providers</h2>
          <p>
            Provider accounts require a business profile and admin approval before receiving
            bookings. Providers are responsible for the quality, licensing, and safety of the work
            they offer.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">4. Bookings</h2>
          <p>
            A booking request is an offer to engage a provider for a described job. Status changes
            (accept, reject, start, complete, cancel, reschedule) must be made only by authorized
            participants. Exact cancellation fees and time windows are to be decided.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">5. Payments</h2>
          <p>
            Online payments will be processed by a gateway selected during implementation. Card
            secrets are not stored in the application database. Commission and payout rules are to
            be decided.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">6. Reviews and conduct</h2>
          <p>
            Reviews may be submitted only for eligible completed bookings. Administrators may
            moderate reviews, complaints, and accounts that violate these terms.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">7. Limitation</h2>
          <p>
            The marketplace is provided as available. To the extent permitted by law, the operator
            is not liable for disputes arising solely from work performed by an independent
            provider. This section will be finalized with legal counsel when the operating entity is
            named.
          </p>
        </section>
      </article>
    </>
  )
}
