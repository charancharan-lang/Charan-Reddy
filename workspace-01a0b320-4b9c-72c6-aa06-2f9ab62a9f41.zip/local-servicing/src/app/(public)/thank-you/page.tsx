import { PageHeader } from "@/components/marketplace/page-header"
import { ButtonLink } from "@/components/ui/button-link"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "Thank you",
  "Your submission was received.",
  "/thank-you",
)

const copy: Record<string, { title: string; description: string }> = {
  contact: {
    title: "Message received",
    description: "Your enquiry was saved. The operations team can follow up when staffing is in place.",
  },
  register: {
    title: "Account created",
    description:
      "Check your email if verification is enabled. You can log in once your account is confirmed.",
  },
  reset: {
    title: "Reset link sent",
    description: "If an account exists for that email, a password reset message is on its way.",
  },
  booking: {
    title: "Booking submitted",
    description: "Your service request was stored. Track it from your bookings once you are signed in.",
  },
}

export default async function ThankYouPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string }>
}) {
  const { type } = await searchParams
  const content = copy[type ?? ""] ?? {
    title: "Thank you",
    description: "Your submission was successful.",
  }

  return (
    <>
      <PageHeader title={content.title} description={content.description} />
      <div className="container-page flex flex-wrap gap-3 py-12">
        <ButtonLink href="/" size="xl">
          Back to home
        </ButtonLink>
        <ButtonLink href="/services" variant="outline" size="xl">
          Browse services
        </ButtonLink>
      </div>
    </>
  )
}
