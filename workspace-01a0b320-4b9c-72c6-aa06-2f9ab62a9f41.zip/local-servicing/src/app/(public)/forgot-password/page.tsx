import Link from "next/link"
import { ForgotPasswordForm } from "@/components/forms/forgot-password-form"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "Forgot password",
  "Request a password reset link for your account.",
  "/forgot-password",
)

export default function ForgotPasswordPage() {
  return (
    <div className="container-page flex justify-center py-12">
      <div className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-sm">
        <h1 className="text-2xl">Forgot password</h1>
        <p className="mt-2 mb-6 text-sm text-muted-foreground">
          Enter the email for your account. If it exists, a reset link will be sent.
        </p>
        <ForgotPasswordForm />
        <p className="mt-6 text-sm text-muted-foreground">
          <Link href="/login" className="font-medium text-primary hover:underline">
            Back to log in
          </Link>
        </p>
      </div>
    </div>
  )
}
