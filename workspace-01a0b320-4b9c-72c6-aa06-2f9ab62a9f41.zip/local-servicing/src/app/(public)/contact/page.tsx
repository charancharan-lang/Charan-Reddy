import { ContactForm } from "@/components/forms/contact-form"
import { PageHeader } from "@/components/marketplace/page-header"
import { pageMetadata } from "@/lib/metadata"

export const metadata = pageMetadata(
  "Contact",
  "Send an enquiry about the local servicing marketplace.",
  "/contact",
)

export default function ContactPage() {
  return (
    <>
      <PageHeader
        title="Contact"
        description="Use this form for product questions and support. A physical business address is not published because brand identity is still to be decided."
      />
      <div className="container-page grid gap-8 py-12 lg:grid-cols-[1fr_18rem]">
        <div className="rounded-2xl border bg-card p-6">
          <ContactForm />
        </div>
        <aside className="h-fit rounded-2xl border bg-muted/40 p-5 text-sm text-muted-foreground">
          <h2 className="mb-2 text-base text-foreground">What happens next</h2>
          <p>
            Valid submissions are stored for the operations team when the database is connected.
            You will be taken to a confirmation page after a successful send.
          </p>
        </aside>
      </div>
    </>
  )
}
