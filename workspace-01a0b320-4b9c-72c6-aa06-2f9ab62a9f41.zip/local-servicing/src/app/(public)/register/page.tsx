import { Suspense } from "react"
import Link from "next/link"
import { RegisterForm } from "@/components/forms/register-form"
import { pageMetadata } from "@/lib/metadata"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata = pageMetadata(
  "Register",
  "Create a customer or service provider account.",
  "/register",
)

export default function RegisterPage() {
  return (
    <div className="container-page flex justify-center py-12">
      <div className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-sm">
        <h1 className="text-2xl">Create an account</h1>
        <p className="mt-2 mb-6 text-sm text-muted-foreground">
          Customers can book services. Providers submit a business profile for admin approval.
        </p>
        <Suspense fallback={<Skeleton className="h-80" />}>
          <RegisterForm />
        </Suspense>
        <p className="mt-6 text-sm text-muted-foreground">
          Already registered?{" "}
          <Link href="/login" className="font-medium text-primary hover:underline">
            Log in
          </Link>
        </p>
      </div>
    </div>
  )
}
