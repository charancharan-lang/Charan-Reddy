import { PageHeader } from "@/components/marketplace/page-header"
import { pageMetadata } from "@/lib/metadata"
import { siteConfig } from "@/lib/site"

export const metadata = pageMetadata(
  "Privacy Policy",
  "How this marketplace handles account, booking, and location information.",
  "/privacy",
)

export default function PrivacyPage() {
  return (
    <>
      <PageHeader
        title="Privacy Policy"
        description="This policy describes the categories of data the product is designed to handle. Operator identity remains to be decided."
      />
      <article className="container-page max-w-3xl space-y-6 py-12 text-muted-foreground">
        <p>Last updated: 18 September 2026.</p>
        <section>
          <h2 className="mb-2 text-foreground">1. Who this applies to</h2>
          <p>
            This policy applies to customers, service providers, and administrators using{" "}
            {siteConfig.name}. A named legal entity, registered address, and data protection officer
            will be added when brand identity is finalized.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">2. Information we collect</h2>
          <ul className="list-disc space-y-2 pl-5">
            <li>Account details such as name, email, phone, role, and authentication data.</li>
            <li>Provider business profile, services, coverage areas, and documents submitted for approval.</li>
            <li>Booking details, private service addresses, photos attached to a job, and messages between booking participants.</li>
            <li>Payment records from the selected gateway. Card secrets are not stored in the application database.</li>
            <li>Locality selections and, if you permit it, browser geolocation coordinates.</li>
            <li>Support enquiries submitted through the contact form.</li>
          </ul>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">3. How information is used</h2>
          <p>
            Data is used to operate search, booking, messaging, payments, reviews, notifications,
            provider approval, and administration. Exact customer addresses are not published on
            public pages.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">4. Sharing</h2>
          <p>
            Booking participants see information required to complete a job. Administrators can
            access records needed for operations and moderation. Processors such as the database,
            authentication, payment, and map providers will be listed when those vendors are chosen.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">5. Cookies</h2>
          <p>
            Essential cookies keep you signed in and remember locality and cookie-consent choices.
            Analytics that expose sensitive personal data are not used.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">6. Retention and rights</h2>
          <p>
            Account and booking records are retained while needed to operate the service and meet
            legal obligations. You may request access, correction, or deletion of your account data
            through the contact form once operations are staffed.
          </p>
        </section>
        <section>
          <h2 className="mb-2 text-foreground">7. Contact</h2>
          <p>
            Use the contact page for privacy questions until a dedicated operator address is
            published.
          </p>
        </section>
      </article>
    </>
  )
}
