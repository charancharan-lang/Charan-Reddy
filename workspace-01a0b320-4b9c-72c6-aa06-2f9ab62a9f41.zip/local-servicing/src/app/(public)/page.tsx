import Link from "next/link"
import {
  CalendarCheck,
  MapPinned,
  MessageSquare,
  ShieldCheck,
  Star,
  Search,
  UserPlus,
  Wallet,
} from "lucide-react"
import { CategoryCard } from "@/components/marketplace/category-card"
import { EmptyState } from "@/components/marketplace/empty-state"
import { FadeIn } from "@/components/motion/fade-in"
import { SearchBar } from "@/components/marketplace/search-bar"
import { SectionHeading } from "@/components/marketplace/section-heading"
import { ServiceCard } from "@/components/marketplace/service-card"
import { ButtonLink } from "@/components/ui/button-link"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { getCategories, getServices } from "@/lib/data/catalog"
import { FAQS } from "@/lib/catalog"
import { siteConfig } from "@/lib/site"

export default async function HomePage() {
  const [categories, services] = await Promise.all([getCategories(), getServices()])
  const popularServices = services.slice(0, 8)

  return (
    <>
      <section className="hero-grid border-b">
        <div className="container-page grid gap-8 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:py-20">
          <FadeIn>
            <p className="mb-3 text-sm font-medium tracking-wide text-primary uppercase">
              Local servicing marketplace
            </p>
            <h1 className="max-w-xl text-4xl sm:text-5xl lg:text-[3.5rem]">
              {siteConfig.tagline}
            </h1>
            <p className="mt-4 max-w-xl text-lg text-muted-foreground">
              {siteConfig.description}
            </p>
            <div className="mt-8">
              <SearchBar />
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {categories.slice(0, 6).map((category) => (
                <Link
                  key={category.slug}
                  href={`/services/${category.slug}`}
                  className="rounded-full border bg-background px-3 py-1.5 text-sm text-muted-foreground hover:border-primary hover:text-foreground"
                >
                  {category.name}
                </Link>
              ))}
            </div>
          </FadeIn>
          <FadeIn delay={0.1} className="hidden lg:block">
            <div className="rounded-3xl bg-card p-6 shadow-lg ring-1 ring-foreground/10">
              <p className="text-sm font-medium text-primary">How booking works</p>
              <ol className="mt-4 grid gap-4">
                {[
                  "Choose a locality and the service you need.",
                  "Compare nearby providers on price, rating, and availability.",
                  "Request a time, share details, and track the job.",
                ].map((step, index) => (
                  <li key={step} className="flex gap-3">
                    <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary text-sm font-semibold text-primary">
                      {index + 1}
                    </span>
                    <p className="pt-1 text-sm text-muted-foreground">{step}</p>
                  </li>
                ))}
              </ol>
              <ButtonLink href="/register?role=provider" variant="outline" size="lg" className="mt-6">
                Become a Service Provider
              </ButtonLink>
            </div>
          </FadeIn>
        </div>
      </section>

      <section className="container-page py-16">
        <SectionHeading
          eyebrow="Categories"
          title="Popular categories"
          description="Browse the service types available on the marketplace."
          action={
            <ButtonLink href="/services" variant="outline" size="lg">
              View all services
            </ButtonLink>
          }
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {categories.map((category, index) => (
            <FadeIn key={category.id} delay={index * 0.03}>
              <CategoryCard category={category} />
            </FadeIn>
          ))}
        </div>
      </section>

      <section className="bg-secondary/40 py-16">
        <div className="container-page">
          <SectionHeading
            eyebrow="Services"
            title="Popular services"
            description="Start a search from a specific job type."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {popularServices.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-16">
        <SectionHeading
          eyebrow="Nearby"
          title="Nearby providers"
          description="Approved providers who serve your selected locality will appear here."
        />
        <EmptyState
          icon={<MapPinned className="size-5" />}
          title="No providers to show yet"
          description="Provider listings come from approved business profiles in the database. None are listed for this view."
          action={
            <ButtonLink href="/register?role=provider" size="lg">
              Become a Service Provider
            </ButtonLink>
          }
        />
      </section>

      <section className="bg-muted/50 py-16">
        <div className="container-page">
          <SectionHeading
            eyebrow="Ratings"
            title="Top-rated professionals"
            description="Rankings are based on reviews from completed jobs only."
          />
          <EmptyState
            icon={<Star className="size-5" />}
            title="No ratings yet"
            description="Top-rated professionals will appear after customers review completed services."
            action={
              <ButtonLink href="/search" variant="outline" size="lg">
                Search Services
              </ButtonLink>
            }
          />
        </div>
      </section>

      <section className="container-page py-16">
        <SectionHeading
          eyebrow="Process"
          title="How it works"
          description="A clear path from search to a completed job."
        />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: Search,
              title: "Search locally",
              text: "Pick a locality and service so results stay relevant to your area.",
            },
            {
              icon: ShieldCheck,
              title: "Compare providers",
              text: "Review profiles, pricing, availability, and completed-job ratings.",
            },
            {
              icon: CalendarCheck,
              title: "Book a time",
              text: "Share job details and photos, then submit a booking request.",
            },
            {
              icon: MessageSquare,
              title: "Stay in touch",
              text: "Message the provider, track status, pay when enabled, and review.",
            },
          ].map((item) => (
            <div key={item.title} className="rounded-2xl border bg-card p-5">
              <item.icon className="mb-3 size-6 text-primary" aria-hidden="true" />
              <h3 className="font-heading text-lg font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-secondary/40 py-16">
        <div className="container-page">
          <SectionHeading
            eyebrow="Why this marketplace"
            title="Why choose us"
            description="Built around discovery, booking, and accountable completed work — without invented claims."
          />
          <div className="grid gap-4 md:grid-cols-3">
            {[
              {
                icon: MapPinned,
                title: "Location-aware search",
                text: "Filter by locality, distance, price, rating, availability, and service type.",
              },
              {
                icon: ShieldCheck,
                title: "Admin-approved providers",
                text: "Providers submit a profile and documents before they can receive jobs.",
              },
              {
                icon: Wallet,
                title: "Booking and payments",
                text: "Track requests, job status, and payment history through your account.",
              },
            ].map((item) => (
              <div key={item.title} className="rounded-2xl bg-card p-5 ring-1 ring-foreground/10">
                <item.icon className="mb-3 size-6 text-primary" aria-hidden="true" />
                <h3 className="font-heading text-lg font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-16">
        <SectionHeading
          eyebrow="Reviews"
          title="Customer reviews"
          description="Reviews are collected only after a booking is completed."
        />
        <EmptyState
          icon={<Star className="size-5" />}
          title="No published reviews"
          description="When customers review completed jobs, those reviews will appear here after moderation rules allow."
        />
      </section>

      <section className="border-y bg-primary text-primary-foreground">
        <div className="container-page flex flex-col items-start gap-4 py-12 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-primary-foreground">Offer your services locally</h2>
            <p className="mt-2 max-w-xl text-primary-foreground/80">
              Create a provider account, add services and coverage, and submit your profile for
              approval.
            </p>
          </div>
          <ButtonLink
            href="/register?role=provider"
            variant="secondary"
            size="xl"
            className="bg-background text-foreground hover:bg-background/90"
          >
            <UserPlus className="size-4" />
            Become a Service Provider
          </ButtonLink>
        </div>
      </section>

      <section className="container-page py-16">
        <SectionHeading
          eyebrow="Help"
          title="Frequently asked questions"
          action={
            <ButtonLink href="/faq" variant="outline" size="lg">
              View all FAQs
            </ButtonLink>
          }
        />
        <Accordion className="rounded-2xl border bg-card px-4">
          {FAQS.slice(0, 5).map((item) => (
            <AccordionItem key={item.question} value={item.question}>
              <AccordionTrigger className="py-4 text-base">{item.question}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{item.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </>
  )
}
