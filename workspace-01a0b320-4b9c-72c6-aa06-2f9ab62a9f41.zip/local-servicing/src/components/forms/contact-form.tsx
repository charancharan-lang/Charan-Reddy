"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { contactAction } from "@/lib/actions/contact"
import { contactSchema, type ContactInput } from "@/lib/validations"
import { Button } from "@/components/ui/button"
import { Field } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function ContactForm() {
  const [serverError, setServerError] = useState<string | null>(null)
  const form = useForm<ContactInput>({
    resolver: zodResolver(contactSchema),
    defaultValues: { name: "", email: "", phone: "", subject: "", message: "" },
  })

  async function onSubmit(values: ContactInput) {
    setServerError(null)
    const result = await contactAction(values)
    if (result && "error" in result) setServerError(result.error)
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4" noValidate>
      {serverError ? (
        <Alert variant="destructive">
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      ) : null}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="name" label="Name" required error={form.formState.errors.name?.message}>
          <Input id="name" autoComplete="name" {...form.register("name")} />
        </Field>
        <Field id="email" label="Email" required error={form.formState.errors.email?.message}>
          <Input id="email" type="email" autoComplete="email" {...form.register("email")} />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="phone" label="Phone" error={form.formState.errors.phone?.message}>
          <Input id="phone" type="tel" autoComplete="tel" {...form.register("phone")} />
        </Field>
        <Field
          id="subject"
          label="Subject"
          required
          error={form.formState.errors.subject?.message}
        >
          <Input id="subject" {...form.register("subject")} />
        </Field>
      </div>
      <Field
        id="message"
        label="Message"
        required
        error={form.formState.errors.message?.message}
      >
        <Textarea id="message" rows={6} className="min-h-32" {...form.register("message")} />
      </Field>
      <Button type="submit" size="xl" disabled={form.formState.isSubmitting}>
        {form.formState.isSubmitting ? "Sending…" : "Send message"}
      </Button>
    </form>
  )
}
