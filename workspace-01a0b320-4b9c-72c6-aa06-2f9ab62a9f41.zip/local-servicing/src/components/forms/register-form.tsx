"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { registerAction } from "@/lib/actions/auth"
import { registerSchema, type RegisterInput } from "@/lib/validations"
import { Button } from "@/components/ui/button"
import { Field } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Label } from "@/components/ui/label"

export function RegisterForm() {
  const searchParams = useSearchParams()
  const roleParam = searchParams.get("role") === "provider" ? "provider" : "customer"
  const [serverError, setServerError] = useState<string | null>(null)
  const form = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
      role: roleParam,
    },
  })

  async function onSubmit(values: RegisterInput) {
    setServerError(null)
    const result = await registerAction(values)
    if (result && "error" in result) setServerError(result.error)
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4" noValidate>
      {serverError ? (
        <Alert variant="destructive">
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      ) : null}
      <Field id="name" label="Full name" required error={form.formState.errors.name?.message}>
        <Input
          id="name"
          autoComplete="name"
          aria-invalid={Boolean(form.formState.errors.name)}
          {...form.register("name")}
        />
      </Field>
      <Field id="email" label="Email" required error={form.formState.errors.email?.message}>
        <Input
          id="email"
          type="email"
          autoComplete="email"
          aria-invalid={Boolean(form.formState.errors.email)}
          {...form.register("email")}
        />
      </Field>
      <Field id="phone" label="Phone" required error={form.formState.errors.phone?.message}>
        <Input
          id="phone"
          type="tel"
          autoComplete="tel"
          aria-invalid={Boolean(form.formState.errors.phone)}
          {...form.register("phone")}
        />
      </Field>
      <div className="grid gap-1.5">
        <Label>Account type</Label>
        <RadioGroup
          value={form.watch("role")}
          onValueChange={(value) => {
            if (value === "customer" || value === "provider") {
              form.setValue("role", value, { shouldValidate: true })
            }
          }}
          className="grid gap-2 sm:grid-cols-2"
        >
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border bg-card p-3 has-data-checked:border-primary has-data-checked:ring-2 has-data-checked:ring-ring/40">
            <RadioGroupItem value="customer" />
            <span>
              <span className="block text-sm font-medium">Customer</span>
              <span className="text-xs text-muted-foreground">
                Find and book local professionals.
              </span>
            </span>
          </label>
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border bg-card p-3 has-data-checked:border-primary has-data-checked:ring-2 has-data-checked:ring-ring/40">
            <RadioGroupItem value="provider" />
            <span>
              <span className="block text-sm font-medium">Service provider</span>
              <span className="text-xs text-muted-foreground">
                Offer services and manage jobs.
              </span>
            </span>
          </label>
        </RadioGroup>
        {form.formState.errors.role?.message ? (
          <p className="text-xs text-destructive" role="alert">
            {form.formState.errors.role.message}
          </p>
        ) : null}
      </div>
      <Field
        id="password"
        label="Password"
        required
        error={form.formState.errors.password?.message}
      >
        <Input
          id="password"
          type="password"
          autoComplete="new-password"
          aria-invalid={Boolean(form.formState.errors.password)}
          {...form.register("password")}
        />
      </Field>
      <Field
        id="confirmPassword"
        label="Confirm password"
        required
        error={form.formState.errors.confirmPassword?.message}
      >
        <Input
          id="confirmPassword"
          type="password"
          autoComplete="new-password"
          aria-invalid={Boolean(form.formState.errors.confirmPassword)}
          {...form.register("confirmPassword")}
        />
      </Field>
      <Button type="submit" size="xl" disabled={form.formState.isSubmitting}>
        {form.formState.isSubmitting ? "Creating account…" : "Create account"}
      </Button>
    </form>
  )
}
