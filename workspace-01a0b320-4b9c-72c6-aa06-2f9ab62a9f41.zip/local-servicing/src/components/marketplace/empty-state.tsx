import type { ReactNode } from "react"
import { Inbox } from "lucide-react"
import { cn } from "@/lib/utils"

export function EmptyState({
  title,
  description,
  action,
  className,
  icon,
}: {
  title: string
  description: string
  action?: ReactNode
  className?: string
  icon?: ReactNode
}) {
  return (
    <div
      className={cn(
        "grid justify-items-center gap-3 rounded-2xl border border-dashed bg-muted/40 px-6 py-12 text-center",
        className,
      )}
    >
      <span className="flex size-12 items-center justify-center rounded-full bg-secondary text-primary">
        {icon ?? <Inbox className="size-5" aria-hidden="true" />}
      </span>
      <div className="grid max-w-md gap-1">
        <h3 className="font-heading text-lg font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      {action}
    </div>
  )
}
