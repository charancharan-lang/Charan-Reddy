import Link from "next/link"
import { MapPin } from "lucide-react"
import { RatingDisplay } from "@/components/marketplace/rating"
import { StatusBadge } from "@/components/marketplace/status-badge"
import { ButtonLink } from "@/components/ui/button-link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { formatCurrency, formatDistance } from "@/lib/site"
import type { ProviderCardData } from "@/types"

export function ProviderCard({ provider }: { provider: ProviderCardData }) {
  const initials = provider.businessName
    .split(" ")
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase()

  return (
    <Card className="h-full">
      <CardContent className="flex flex-col gap-4">
        <div className="flex items-start gap-3">
          <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-secondary font-semibold text-primary">
            {initials || "P"}
          </div>
          <div className="min-w-0 grid gap-1">
            <Link
              href={`/providers/${provider.id}`}
              className="font-heading truncate text-base font-semibold hover:underline"
            >
              {provider.businessName}
            </Link>
            {provider.categoryName ? (
              <p className="text-sm text-muted-foreground">{provider.categoryName}</p>
            ) : null}
            <RatingDisplay rating={provider.rating} count={provider.reviewCount} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          {provider.locality ? (
            <span className="inline-flex items-center gap-1">
              <MapPin className="size-3.5" aria-hidden="true" />
              {provider.locality}
            </span>
          ) : null}
          {provider.distanceKm != null ? (
            <span>{formatDistance(provider.distanceKm)}</span>
          ) : null}
          {provider.startingPrice != null ? (
            <span>From {formatCurrency(provider.startingPrice)}</span>
          ) : null}
          {provider.availableToday ? <StatusBadge status="available" /> : null}
        </div>
        {provider.shortBio ? (
          <p className="line-clamp-2 text-sm text-muted-foreground">{provider.shortBio}</p>
        ) : null}
      </CardContent>
      <CardFooter className="justify-between gap-2">
        <ButtonLink href={`/providers/${provider.id}`} variant="outline" size="lg">
          View profile
        </ButtonLink>
        <ButtonLink href={`/providers/${provider.id}#book`} size="lg">
          Book Service
        </ButtonLink>
      </CardFooter>
    </Card>
  )
}
