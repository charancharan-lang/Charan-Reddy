import { Map } from "lucide-react"
import { siteConfig } from "@/lib/site"

export function MapPanel({ className }: { className?: string }) {
  const configured = siteConfig.mapProvider !== "none"

  return (
    <aside
      className={className}
      aria-label="Map"
    >
      <div className="flex h-full min-h-[18rem] flex-col items-center justify-center gap-3 rounded-2xl border bg-muted/40 p-6 text-center">
        <span className="flex size-12 items-center justify-center rounded-full bg-secondary text-primary">
          <Map className="size-5" aria-hidden="true" />
        </span>
        <div className="grid max-w-sm gap-1">
          <h3 className="font-heading text-base font-semibold">
            {configured ? "Map view" : "Map provider not configured"}
          </h3>
          <p className="text-sm text-muted-foreground">
            {configured
              ? "Provider locations will appear on the map for the selected locality."
              : "Search still works as a list. A map can be connected once a provider is chosen."}
          </p>
        </div>
      </div>
    </aside>
  )
}
