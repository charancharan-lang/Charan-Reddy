import Link from "next/link"
import { CategoryIcon } from "@/components/marketplace/category-icon"
import { Card, CardContent } from "@/components/ui/card"
import type { ServiceCategory } from "@/types"
import { cn } from "@/lib/utils"

export function CategoryCard({
  category,
  className,
}: {
  category: ServiceCategory
  className?: string
}) {
  return (
    <Link
      href={`/services/${category.slug}`}
      className={cn(
        "block rounded-2xl outline-none focus-visible:ring-3 focus-visible:ring-ring/50",
        className,
      )}
    >
      <Card className="h-full transition-shadow hover:shadow-md">
        <CardContent className="flex h-full flex-col gap-3 pt-1">
          <span className="flex size-11 items-center justify-center rounded-xl bg-secondary text-primary">
            <CategoryIcon name={category.icon} />
          </span>
          <div className="grid gap-1">
            <h3 className="font-heading text-base font-semibold">{category.name}</h3>
            <p className="text-sm text-muted-foreground">{category.description}</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
