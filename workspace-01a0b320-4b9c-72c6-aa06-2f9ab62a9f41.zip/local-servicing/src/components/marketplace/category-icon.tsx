import {
  Car,
  Droplets,
  GlassWater,
  Hammer,
  Paintbrush,
  Smartphone,
  Snowflake,
  Sparkles,
  WashingMachine,
  Wrench,
  Zap,
  type LucideIcon,
} from "lucide-react"
import { cn } from "@/lib/utils"

const icons: Record<string, LucideIcon> = {
  snowflake: Snowflake,
  zap: Zap,
  droplets: Droplets,
  car: Car,
  "washing-machine": WashingMachine,
  sparkles: Sparkles,
  paintbrush: Paintbrush,
  hammer: Hammer,
  smartphone: Smartphone,
  "glass-water": GlassWater,
  wrench: Wrench,
}

export function CategoryIcon({
  name,
  className,
}: {
  name: string
  className?: string
}) {
  const Icon = icons[name] ?? Wrench
  return <Icon className={cn("size-6", className)} aria-hidden="true" />
}
