import { Star } from "lucide-react"
import { cn } from "@/lib/utils"

export function RatingDisplay({
  rating,
  count,
  className,
}: {
  rating?: number | null
  count?: number
  className?: string
}) {
  if (rating == null) {
    return (
      <span className={cn("text-sm text-muted-foreground", className)}>No reviews yet</span>
    )
  }

  return (
    <span className={cn("inline-flex items-center gap-1 text-sm font-medium", className)}>
      <Star className="size-4 fill-warning text-warning" aria-hidden="true" />
      <span>{rating.toFixed(1)}</span>
      {typeof count === "number" ? (
        <span className="font-normal text-muted-foreground">({count})</span>
      ) : null}
    </span>
  )
}
