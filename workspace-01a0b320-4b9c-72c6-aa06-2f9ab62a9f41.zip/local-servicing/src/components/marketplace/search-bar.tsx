"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { LocationSelector, useLocality } from "@/components/marketplace/location-selector"
import { cn } from "@/lib/utils"

export function SearchBar({
  defaultQuery = "",
  defaultCategory = "",
  variant = "hero",
  className,
}: {
  defaultQuery?: string
  defaultCategory?: string
  variant?: "hero" | "compact"
  className?: string
}) {
  const router = useRouter()
  const locality = useLocality()
  const [query, setQuery] = useState(defaultQuery)

  function submit(event: React.FormEvent) {
    event.preventDefault()
    const params = new URLSearchParams()
    if (query.trim()) params.set("q", query.trim())
    if (locality?.label) params.set("location", locality.label)
    if (defaultCategory) params.set("category", defaultCategory)
    router.push(`/search?${params.toString()}`)
  }

  const isHero = variant === "hero"

  return (
    <form
      onSubmit={submit}
      className={cn(
        "grid gap-3",
        isHero
          ? "rounded-2xl bg-card p-3 shadow-lg ring-1 ring-foreground/10 sm:grid-cols-[auto_1fr_auto] sm:items-end sm:p-4"
          : "sm:grid-cols-[auto_1fr_auto] sm:items-end",
        className,
      )}
    >
      <div className="grid gap-1.5">
        {isHero ? (
          <Label htmlFor="search-location" className="text-xs text-muted-foreground">
            Locality
          </Label>
        ) : null}
        <LocationSelector className="w-full sm:w-[13.5rem]" />
      </div>
      <div className="grid gap-1.5">
        {isHero ? (
          <Label htmlFor="search-query" className="text-xs text-muted-foreground">
            Service
          </Label>
        ) : null}
        <div className="relative">
          <Search
            className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            id="search-query"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search AC repair, plumbing, cleaning…"
            className="pl-9"
          />
        </div>
      </div>
      <Button type="submit" size="xl" className="w-full sm:w-auto">
        <Search className="size-4" />
        Search Services
      </Button>
    </form>
  )
}
