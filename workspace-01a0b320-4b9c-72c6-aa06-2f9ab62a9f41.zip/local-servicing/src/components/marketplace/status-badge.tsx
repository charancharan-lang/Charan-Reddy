import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

const styles: Record<string, string> = {
  pending: "bg-warning/15 text-warning-foreground",
  accepted: "bg-info/15 text-info",
  in_progress: "bg-info/15 text-info",
  completed: "bg-success/15 text-success",
  cancelled: "bg-muted text-muted-foreground",
  rejected: "bg-destructive/10 text-destructive",
  rescheduled: "bg-accent text-accent-foreground",
  available: "bg-success/15 text-success",
  unavailable: "bg-muted text-muted-foreground",
  approved: "bg-success/15 text-success",
  suspended: "bg-destructive/10 text-destructive",
}

export function StatusBadge({
  status,
  className,
}: {
  status: string
  className?: string
}) {
  const label = status.replaceAll("_", " ")
  return (
    <Badge
      variant="secondary"
      className={cn("capitalize", styles[status] ?? "", className)}
    >
      {label}
    </Badge>
  )
}
