export function PageHeader({
  title,
  description,
}: {
  title: string
  description?: string
}) {
  return (
    <header className="border-b bg-secondary/40">
      <div className="container-page py-10 sm:py-14">
        <h1>{title}</h1>
        {description ? (
          <p className="mt-3 max-w-2xl text-base text-muted-foreground sm:text-lg">
            {description}
          </p>
        ) : null}
      </div>
    </header>
  )
}
