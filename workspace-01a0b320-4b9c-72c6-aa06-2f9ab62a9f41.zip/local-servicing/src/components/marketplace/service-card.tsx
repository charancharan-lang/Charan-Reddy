import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import type { CatalogService } from "@/types"

export function ServiceCard({ service }: { service: CatalogService }) {
  return (
    <Card className="h-full">
      <CardContent className="flex h-full flex-col gap-3">
        <div className="grid gap-1">
          <h3 className="font-heading text-base font-semibold">{service.name}</h3>
          <p className="text-sm text-muted-foreground">{service.description}</p>
        </div>
        <Link
          href={`/search?service=${service.slug}&category=${service.categorySlug}`}
          className="mt-auto inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
        >
          Find providers
          <ArrowRight className="size-4" />
        </Link>
      </CardContent>
    </Card>
  )
}
