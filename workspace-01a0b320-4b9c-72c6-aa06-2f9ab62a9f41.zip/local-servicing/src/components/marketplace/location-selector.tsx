"use client"

import { useEffect, useState } from "react"
import { MapPin, Navigation, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import type { Locality } from "@/types"

const STORAGE_KEY = "locality"

function readLocality(): Locality | null {
  if (typeof window === "undefined") return null
  const raw = window.localStorage.getItem(STORAGE_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw) as Locality
  } catch {
    return null
  }
}

function persistLocality(value: Locality | null) {
  if (value) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(value))
    document.cookie = `locality=${encodeURIComponent(value.label)}; path=/; max-age=31536000; samesite=lax`
  } else {
    window.localStorage.removeItem(STORAGE_KEY)
    document.cookie = "locality=; path=/; max-age=0"
  }
  window.dispatchEvent(new Event("locality-change"))
}

export function useLocality() {
  const [locality, setLocality] = useState<Locality | null>(null)

  useEffect(() => {
    setLocality(readLocality())
    const onChange = () => setLocality(readLocality())
    window.addEventListener("locality-change", onChange)
    window.addEventListener("storage", onChange)
    return () => {
      window.removeEventListener("locality-change", onChange)
      window.removeEventListener("storage", onChange)
    }
  }, [])

  return locality
}

export function LocationSelector({
  compact = false,
  className,
}: {
  compact?: boolean
  className?: string
}) {
  const locality = useLocality()
  const [open, setOpen] = useState(false)
  const [value, setValue] = useState("")
  const [geoError, setGeoError] = useState<string | null>(null)
  const [geoLoading, setGeoLoading] = useState(false)

  useEffect(() => {
    if (open) {
      setValue(locality?.label ?? "")
      setGeoError(null)
    }
  }, [open, locality])

  function saveTyped() {
    const label = value.trim()
    if (!label) return
    persistLocality({ label, source: "typed" })
    setOpen(false)
  }

  function useGeolocation() {
    if (!navigator.geolocation) {
      setGeoError("Geolocation is not supported in this browser.")
      return
    }
    setGeoLoading(true)
    setGeoError(null)
    navigator.geolocation.getCurrentPosition(
      (position) => {
        persistLocality({
          label: "Current location",
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          source: "geolocation",
        })
        setGeoLoading(false)
        setOpen(false)
      },
      (error) => {
        setGeoLoading(false)
        if (error.code === error.PERMISSION_DENIED) {
          setGeoError("Location permission was denied. You can type a locality instead.")
        } else {
          setGeoError("Could not read your location. Type a locality instead.")
        }
      },
      { enableHighAccuracy: false, timeout: 10000 },
    )
  }

  return (
    <>
      <Button
        type="button"
        variant={compact ? "ghost" : "outline"}
        size={compact ? "sm" : "lg"}
        onClick={() => setOpen(true)}
        className={cn(
          "max-w-[14rem] justify-start gap-2 font-medium",
          compact ? "h-9 px-2" : "h-11 bg-background",
          className,
        )}
        aria-haspopup="dialog"
        aria-expanded={open}
      >
        <MapPin className="size-4 text-primary" aria-hidden="true" />
        <span className="truncate">
          {locality?.label ?? (compact ? "Locality" : "Select locality")}
        </span>
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Choose your locality</DialogTitle>
            <DialogDescription>
              Results use the locality you select. Your exact street address is never shown
              publicly.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="locality-input">Locality or area</Label>
              <Input
                id="locality-input"
                value={value}
                onChange={(event) => setValue(event.target.value)}
                placeholder="e.g. neighbourhood or city area"
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault()
                    saveTyped()
                  }
                }}
              />
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button type="button" size="lg" onClick={saveTyped} disabled={!value.trim()}>
                Save locality
              </Button>
              <Button
                type="button"
                size="lg"
                variant="outline"
                onClick={useGeolocation}
                disabled={geoLoading}
              >
                <Navigation className="size-4" />
                {geoLoading ? "Detecting…" : "Use current location"}
              </Button>
            </div>
            {geoError ? (
              <p className="text-sm text-destructive" role="alert">
                {geoError}
              </p>
            ) : null}
            {locality ? (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="justify-start text-muted-foreground"
                onClick={() => {
                  persistLocality(null)
                  setValue("")
                }}
              >
                <X className="size-4" />
                Clear selected locality
              </Button>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
