"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { SEED_CATEGORIES } from "@/lib/catalog"

function setParam(
  params: URLSearchParams,
  key: string,
  value: string | undefined,
) {
  if (!value || value === "any") params.delete(key)
  else params.set(key, value)
}

export function FilterPanel() {
  const router = useRouter()
  const searchParams = useSearchParams()

  function update(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString())
    setParam(params, key, value)
    router.push(`/search?${params.toString()}`)
  }

  return (
    <div className="grid gap-4">
      <div className="grid gap-1.5">
        <Label htmlFor="filter-category">Service type</Label>
        <Select
          value={searchParams.get("category") ?? "any"}
          onValueChange={(value) => update("category", value ?? "any")}
        >
          <SelectTrigger id="filter-category" className="h-11 w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">All categories</SelectItem>
            {SEED_CATEGORIES.map((category) => (
              <SelectItem key={category.slug} value={category.slug}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="filter-sort">Sort by</Label>
        <Select
          value={searchParams.get("sort") ?? "distance"}
          onValueChange={(value) => update("sort", value ?? "distance")}
        >
          <SelectTrigger id="filter-sort" className="h-11 w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="distance">Distance</SelectItem>
            <SelectItem value="rating">Rating</SelectItem>
            <SelectItem value="price">Price</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="filter-radius">Distance radius</Label>
        <Select
          value={searchParams.get("radius") ?? "any"}
          onValueChange={(value) => update("radius", value ?? "any")}
        >
          <SelectTrigger id="filter-radius" className="h-11 w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any distance</SelectItem>
            <SelectItem value="5">Within 5 km</SelectItem>
            <SelectItem value="10">Within 10 km</SelectItem>
            <SelectItem value="25">Within 25 km</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="filter-rating">Minimum rating</Label>
        <Select
          value={searchParams.get("minRating") ?? "any"}
          onValueChange={(value) => update("minRating", value ?? "any")}
        >
          <SelectTrigger id="filter-rating" className="h-11 w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any rating</SelectItem>
            <SelectItem value="3">3+</SelectItem>
            <SelectItem value="4">4+</SelectItem>
            <SelectItem value="4.5">4.5+</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="filter-availability">Availability</Label>
        <Select
          value={searchParams.get("availability") ?? "any"}
          onValueChange={(value) => update("availability", value ?? "any")}
        >
          <SelectTrigger id="filter-availability" className="h-11 w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any time</SelectItem>
            <SelectItem value="today">Available today</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button
        type="button"
        variant="ghost"
        onClick={() => router.push("/search")}
      >
        Clear filters
      </Button>
    </div>
  )
}
