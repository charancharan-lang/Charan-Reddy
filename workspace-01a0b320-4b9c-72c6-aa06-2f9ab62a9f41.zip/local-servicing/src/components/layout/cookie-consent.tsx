"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const KEY = "cookie-consent"

export function CookieConsent() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    setVisible(!window.localStorage.getItem(KEY))
  }, [])

  if (!visible) return null

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 p-4">
      <div className="container-page flex flex-col gap-3 rounded-2xl bg-foreground p-4 text-background shadow-lg sm:flex-row sm:items-center">
        <p className="text-sm">
          This site uses essential cookies to keep you signed in and remember your
          locality. See the{" "}
          <Link href="/privacy" className="underline underline-offset-2">
            Privacy Policy
          </Link>
          .
        </p>
        <div className="flex shrink-0 gap-2">
          <Button
            type="button"
            variant="secondary"
            size="lg"
            onClick={() => {
              window.localStorage.setItem(KEY, "accepted")
              setVisible(false)
            }}
          >
            Accept
          </Button>
        </div>
      </div>
    </div>
  )
}
