import Link from "next/link"
import { siteConfig } from "@/lib/site"
import { cn } from "@/lib/utils"

export function Logo({
  className,
  compact = false,
}: {
  className?: string
  compact?: boolean
}) {
  return (
    <Link
      href="/"
      className={cn(
        "flex items-center gap-2 rounded-lg outline-none focus-visible:ring-3 focus-visible:ring-ring/50",
        className,
      )}
    >
      <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <svg viewBox="0 0 24 24" className="size-5" fill="none" aria-hidden="true">
          <path
            d="M12 3.2 4.8 9v11.2h4.8v-6.4h4.8v6.4h4.8V9L12 3.2Z"
            stroke="currentColor"
            strokeWidth="1.7"
            strokeLinejoin="round"
          />
          <path
            d="M9.2 13.2h5.6"
            stroke="currentColor"
            strokeWidth="1.7"
            strokeLinecap="round"
          />
        </svg>
      </span>
      {compact ? (
        <span className="sr-only">{siteConfig.name}</span>
      ) : (
        <span className="font-heading text-base font-semibold tracking-tight sm:text-lg">
          {siteConfig.name}
        </span>
      )}
    </Link>
  )
}
