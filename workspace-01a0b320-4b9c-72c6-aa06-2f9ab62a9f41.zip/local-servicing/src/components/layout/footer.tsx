import Link from "next/link"
import { Logo } from "@/components/layout/logo"
import { ButtonLink } from "@/components/ui/button-link"
import { SEED_CATEGORIES } from "@/lib/catalog"
import { legalNav, publicNav, siteConfig } from "@/lib/site"

export function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="border-t bg-card">
      <div className="container-wide grid gap-10 py-12 md:grid-cols-2 lg:grid-cols-4">
        <div className="grid gap-3">
          <Logo />
          <p className="max-w-xs text-sm text-muted-foreground">{siteConfig.description}</p>
          <ButtonLink href="/register?role=provider" variant="outline" size="lg">
            Become a Service Provider
          </ButtonLink>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-semibold">Explore</h2>
          <ul className="grid gap-2 text-sm">
            {publicNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-muted-foreground hover:text-foreground">
                  {item.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/search" className="text-muted-foreground hover:text-foreground">
                Search
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-semibold">Service categories</h2>
          <ul className="grid gap-2 text-sm">
            {SEED_CATEGORIES.slice(0, 8).map((category) => (
              <li key={category.slug}>
                <Link
                  href={`/services/${category.slug}`}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {category.name}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/services" className="font-medium text-primary hover:underline">
                All services
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-semibold">Support & legal</h2>
          <ul className="grid gap-2 text-sm">
            <li>
              <Link href="/faq" className="text-muted-foreground hover:text-foreground">
                FAQ
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                Contact
              </Link>
            </li>
            {legalNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-muted-foreground hover:text-foreground">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t">
        <div className="container-wide flex flex-col gap-2 py-4 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {siteConfig.name}. All rights reserved.
          </p>
          <p>Brand identity, payment gateway, and map provider are still to be decided.</p>
        </div>
      </div>
    </footer>
  )
}
