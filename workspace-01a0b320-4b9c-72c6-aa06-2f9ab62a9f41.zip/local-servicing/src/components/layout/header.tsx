"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, Search } from "lucide-react"
import { Logo } from "@/components/layout/logo"
import { LocationSelector } from "@/components/marketplace/location-selector"
import { Button } from "@/components/ui/button"
import { ButtonLink } from "@/components/ui/button-link"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import { publicNav, siteConfig } from "@/lib/site"
import { cn } from "@/lib/utils"

export function Header() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur-md">
      <div className="container-wide flex h-16 items-center gap-3">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={() => setOpen(true)}
          aria-label="Open menu"
        >
          <Menu className="size-5" />
        </Button>
        <Logo />
        <nav className="ml-4 hidden items-center gap-1 lg:flex" aria-label="Primary">
          {publicNav.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname === item.href || pathname.startsWith(`${item.href}/`)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-muted hover:text-foreground",
                  active ? "text-foreground" : "text-muted-foreground",
                )}
                aria-current={active ? "page" : undefined}
              >
                {item.label}
              </Link>
            )
          })}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <div className="hidden md:block">
            <LocationSelector compact />
          </div>
          <ButtonLink href="/search" variant="ghost" size="icon" aria-label="Search services">
            <Search className="size-4" />
          </ButtonLink>
          <ButtonLink href="/login" variant="ghost" size="lg" className="hidden sm:inline-flex">
            Log in
          </ButtonLink>
          <ButtonLink href="/register" size="lg">
            Register
          </ButtonLink>
        </div>
      </div>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-[min(100%,20rem)]">
          <SheetHeader>
            <SheetTitle className="sr-only">{siteConfig.name} menu</SheetTitle>
            <Logo />
          </SheetHeader>
          <nav className="grid gap-1 px-4" aria-label="Mobile">
            {publicNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-sm font-medium hover:bg-muted"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/search"
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-sm font-medium hover:bg-muted"
            >
              Search
            </Link>
          </nav>
          <div className="mt-auto grid gap-2 p-4">
            <LocationSelector className="w-full" />
            <ButtonLink href="/login" variant="outline" size="lg" onClick={() => setOpen(false)}>
              Log in
            </ButtonLink>
            <ButtonLink href="/register" size="lg" onClick={() => setOpen(false)}>
              Register
            </ButtonLink>
          </div>
        </SheetContent>
      </Sheet>
    </header>
  )
}
