# Local Servicing Marketplace

A Next.js 15 marketplace that connects customers with local service providers. Brand identity, payment gateway, map provider, commission model, and cancellation policy remain **To Be Decided**.

## Stack

- Next.js 15 (App Router) + TypeScript
- Tailwind CSS v4 + shadcn/ui
- Lucide React, Framer Motion
- React Hook Form + Zod
- Supabase (Auth, Postgres, RLS)

## Getting started

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Environment

Copy `.env.example` to `.env.local`. Auth, contact submissions, and live provider data require:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Apply `supabase/schema.sql` (and optionally `supabase/seed.sql`) in the Supabase SQL editor.

Do not commit secrets.

## Scripts

| Command | Purpose |
| --- | --- |
| `npm run dev` | Development server |
| `npm run typecheck` | TypeScript |
| `npm run lint` | ESLint |
| `npm run build` | Production build |

## Public routes

Home, About, Services, category details, search, provider profile, login, register, forgot password, contact, FAQ, privacy, terms, thank you, and 404.

Customer, provider, and admin dashboards are planned for later phases.

## Notes

- Service categories on the public site are product taxonomy from the PRD until the database catalog is populated.
- Provider listings, reviews, and statistics are not invented. Empty states are shown until real records exist.
- Map and payment integrations are placeholders until a provider is chosen.
