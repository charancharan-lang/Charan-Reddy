-- Optional taxonomy seed. Safe to re-run.
insert into public.service_categories (slug, name, description, icon, sort_order)
values
  ('ac-repair', 'AC Repair', 'Installation, servicing, gas refill, and repair for air conditioners.', 'snowflake', 1),
  ('electrical', 'Electrical', 'Wiring, switches, lighting, fans, inverter work, and electrical repairs.', 'zap', 2),
  ('plumbing', 'Plumbing', 'Leak repair, tap and pipe fitting, drainage, and water-supply issues.', 'droplets', 3),
  ('vehicle-servicing', 'Vehicle Servicing', 'Periodic servicing and repairs for cars, bikes, and other vehicles.', 'car', 4),
  ('appliance-repair', 'Appliance Repair', 'Repair and maintenance for home appliances.', 'washing-machine', 5),
  ('cleaning', 'Cleaning', 'Home, kitchen, bathroom, sofa, and deep-cleaning services.', 'sparkles', 6),
  ('painting', 'Painting', 'Interior and exterior painting and wall finishing.', 'paintbrush', 7),
  ('carpentry', 'Carpentry', 'Furniture repair, fittings, doors, and custom woodwork.', 'hammer', 8),
  ('computer-mobile-repair', 'Computer & Mobile Repair', 'Laptop, desktop, and smartphone repair.', 'smartphone', 9),
  ('ro-water-purifier', 'RO & Water Purifier', 'Installation, filter replacement, and servicing for purifiers.', 'glass-water', 10),
  ('other-home-services', 'Other Home Services', 'Additional local home and everyday services.', 'wrench', 11)
on conflict (slug) do update set
  name = excluded.name,
  description = excluded.description,
  icon = excluded.icon,
  sort_order = excluded.sort_order;

insert into public.services (category_id, slug, name, description)
select c.id, s.slug, s.name, s.description
from (
  values
    ('ac-repair', 'ac-service', 'AC servicing', 'Routine cleaning and performance check for air conditioners.'),
    ('ac-repair', 'ac-repair-job', 'AC repair', 'Diagnosis and repair for cooling, noise, or leakage issues.'),
    ('ac-repair', 'ac-installation', 'AC installation', 'New split or window AC installation and setup.'),
    ('electrical', 'wiring-repair', 'Wiring repair', 'Fault finding and repair for household electrical wiring.'),
    ('electrical', 'switchboard-repair', 'Switchboard repair', 'Replacement or repair of switches, sockets, and boards.'),
    ('electrical', 'fan-light-installation', 'Fan & light installation', 'Installation or replacement of fans, lights, and fittings.'),
    ('plumbing', 'leak-repair', 'Leak repair', 'Fix leaking taps, pipes, and bathroom fittings.'),
    ('plumbing', 'drain-unclogging', 'Drain unclogging', 'Clear blocked kitchen or bathroom drains.'),
    ('plumbing', 'tap-fitting', 'Tap & mixer fitting', 'Install or replace taps, mixers, and shower fittings.'),
    ('vehicle-servicing', 'car-servicing', 'Car servicing', 'Periodic car service and inspection.'),
    ('vehicle-servicing', 'bike-servicing', 'Bike servicing', 'Two-wheeler servicing and common repairs.'),
    ('appliance-repair', 'refrigerator-repair', 'Refrigerator repair', 'Cooling, noise, and component repair for refrigerators.'),
    ('appliance-repair', 'washing-machine-repair', 'Washing machine repair', 'Diagnosis and repair for washers and dryers.'),
    ('cleaning', 'home-cleaning', 'Home cleaning', 'Standard or deep cleaning for homes and apartments.'),
    ('cleaning', 'kitchen-bathroom-cleaning', 'Kitchen & bathroom cleaning', 'Focused cleaning for kitchens and bathrooms.'),
    ('painting', 'interior-painting', 'Interior painting', 'Room or full-home interior painting.'),
    ('painting', 'exterior-painting', 'Exterior painting', 'Exterior wall painting and weatherproof finishing.'),
    ('carpentry', 'furniture-repair', 'Furniture repair', 'Repair and fitting for wooden furniture.'),
    ('carpentry', 'door-window-work', 'Door & window work', 'Repair or fitting of doors, windows, and frames.'),
    ('computer-mobile-repair', 'laptop-repair', 'Laptop repair', 'Hardware and software repair for laptops.'),
    ('computer-mobile-repair', 'mobile-repair', 'Mobile repair', 'Smartphone screen, battery, and software repair.'),
    ('ro-water-purifier', 'ro-servicing', 'RO servicing', 'Filter checks, cleaning, and performance service.'),
    ('ro-water-purifier', 'filter-replacement', 'Filter replacement', 'Replacement of RO and purifier filters.'),
    ('other-home-services', 'general-handyman', 'General handyman', 'Small home repairs and assembly work.')
) as s(category_slug, slug, name, description)
join public.service_categories c on c.slug = s.category_slug
on conflict (slug) do update set
  name = excluded.name,
  description = excluded.description;
