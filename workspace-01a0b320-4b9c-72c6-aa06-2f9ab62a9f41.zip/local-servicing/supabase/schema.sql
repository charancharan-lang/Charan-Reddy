-- Local Servicing Marketplace — initial schema
-- Apply in the Supabase SQL editor for the development project.

create extension if not exists "pgcrypto";

do $$ begin
  create type public.user_role as enum ('customer', 'provider', 'admin');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.provider_status as enum ('pending', 'approved', 'rejected', 'suspended');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.booking_status as enum (
    'pending', 'accepted', 'rejected', 'in_progress', 'completed', 'cancelled', 'rescheduled'
  );
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.payment_status as enum ('pending', 'paid', 'failed', 'refunded');
exception when duplicate_object then null;
end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null,
  email text not null,
  phone text,
  role public.user_role not null default 'customer',
  avatar_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.provider_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles (id) on delete cascade,
  business_name text not null,
  description text,
  short_bio text,
  phone text,
  logo_url text,
  cover_url text,
  status public.provider_status not null default 'pending',
  locality text,
  service_radius_km numeric,
  rating_avg numeric(3, 2) not null default 0,
  review_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  description text,
  icon text,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.service_categories (id) on delete cascade,
  slug text not null unique,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.provider_services (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid not null references public.provider_profiles (id) on delete cascade,
  service_id uuid not null references public.services (id) on delete cascade,
  price numeric(10, 2),
  price_unit text,
  is_active boolean not null default true,
  unique (provider_id, service_id)
);

create table if not exists public.service_areas (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid not null references public.provider_profiles (id) on delete cascade,
  locality text not null,
  lat double precision,
  lng double precision,
  radius_km numeric
);

create table if not exists public.provider_availability (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid not null references public.provider_profiles (id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6),
  start_time time not null,
  end_time time not null,
  is_available boolean not null default true
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles (id) on delete restrict,
  provider_id uuid not null references public.provider_profiles (id) on delete restrict,
  service_id uuid not null references public.services (id),
  locality text not null,
  address_private text,
  lat double precision,
  lng double precision,
  scheduled_for timestamptz,
  details text,
  status public.booking_status not null default 'pending',
  estimate_amount numeric(10, 2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.booking_attachments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete cascade,
  file_url text not null,
  file_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete restrict,
  customer_id uuid not null references public.profiles (id),
  amount numeric(10, 2) not null,
  currency text not null default 'INR',
  status public.payment_status not null default 'pending',
  provider text,
  provider_reference text,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid unique references public.bookings (id) on delete cascade,
  customer_id uuid not null references public.profiles (id),
  provider_id uuid not null references public.provider_profiles (id),
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id uuid not null references public.profiles (id),
  body text not null,
  attachment_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles (id) on delete cascade,
  provider_id uuid not null references public.provider_profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (customer_id, provider_id)
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings (id) on delete cascade,
  customer_id uuid not null references public.profiles (id),
  provider_id uuid not null references public.provider_profiles (id),
  rating smallint not null check (rating between 1 and 5),
  body text,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  body text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings (id) on delete set null,
  raised_by uuid not null references public.profiles (id),
  against_user_id uuid references public.profiles (id),
  subject text not null,
  body text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  audience text not null default 'all',
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles (id),
  action text not null,
  entity text not null,
  entity_id text,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.contact_inquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text,
  subject text not null,
  message text not null,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', 'User'),
    new.email,
    new.raw_user_meta_data ->> 'phone',
    coalesce((new.raw_user_meta_data ->> 'role')::public.user_role, 'customer')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.provider_profiles enable row level security;
alter table public.service_categories enable row level security;
alter table public.services enable row level security;
alter table public.provider_services enable row level security;
alter table public.service_areas enable row level security;
alter table public.provider_availability enable row level security;
alter table public.bookings enable row level security;
alter table public.booking_attachments enable row level security;
alter table public.payments enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.favorites enable row level security;
alter table public.reviews enable row level security;
alter table public.notifications enable row level security;
alter table public.complaints enable row level security;
alter table public.announcements enable row level security;
alter table public.audit_logs enable row level security;
alter table public.contact_inquiries enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and is_active = true
  );
$$;

drop policy if exists "public read categories" on public.service_categories;
create policy "public read categories" on public.service_categories
  for select using (is_active = true or public.is_admin());

drop policy if exists "admin manage categories" on public.service_categories;
create policy "admin manage categories" on public.service_categories
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read services" on public.services;
create policy "public read services" on public.services
  for select using (is_active = true or public.is_admin());

drop policy if exists "admin manage services" on public.services;
create policy "admin manage services" on public.services
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read approved providers" on public.provider_profiles;
create policy "public read approved providers" on public.provider_profiles
  for select using (status = 'approved' or user_id = auth.uid() or public.is_admin());

drop policy if exists "provider manage own profile" on public.provider_profiles;
create policy "provider manage own profile" on public.provider_profiles
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

drop policy if exists "users read own profile" on public.profiles;
create policy "users read own profile" on public.profiles
  for select using (id = auth.uid() or public.is_admin());

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles
  for update using (id = auth.uid() or public.is_admin());

drop policy if exists "public read provider services" on public.provider_services;
create policy "public read provider services" on public.provider_services
  for select using (is_active = true or public.is_admin());

drop policy if exists "public read service areas" on public.service_areas;
create policy "public read service areas" on public.service_areas
  for select using (true);

drop policy if exists "public read availability" on public.provider_availability;
create policy "public read availability" on public.provider_availability
  for select using (true);

drop policy if exists "public read published reviews" on public.reviews;
create policy "public read published reviews" on public.reviews
  for select using (is_published = true or customer_id = auth.uid() or public.is_admin());

drop policy if exists "customer insert review" on public.reviews;
create policy "customer insert review" on public.reviews
  for insert with check (customer_id = auth.uid());

drop policy if exists "booking participants" on public.bookings;
create policy "booking participants" on public.bookings
  for select using (
    customer_id = auth.uid()
    or public.is_admin()
    or provider_id in (select id from public.provider_profiles where user_id = auth.uid())
  );

drop policy if exists "customer create booking" on public.bookings;
create policy "customer create booking" on public.bookings
  for insert with check (customer_id = auth.uid());

drop policy if exists "authorized update booking" on public.bookings;
create policy "authorized update booking" on public.bookings
  for update using (
    customer_id = auth.uid()
    or public.is_admin()
    or provider_id in (select id from public.provider_profiles where user_id = auth.uid())
  );

drop policy if exists "own favorites" on public.favorites;
create policy "own favorites" on public.favorites
  for all using (customer_id = auth.uid()) with check (customer_id = auth.uid());

drop policy if exists "own notifications" on public.notifications;
create policy "own notifications" on public.notifications
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists "own payments" on public.payments;
create policy "own payments" on public.payments
  for select using (customer_id = auth.uid() or public.is_admin());

drop policy if exists "conversation participants" on public.conversations;
create policy "conversation participants" on public.conversations
  for select using (
    customer_id = auth.uid()
    or public.is_admin()
    or provider_id in (select id from public.provider_profiles where user_id = auth.uid())
  );

drop policy if exists "message participants" on public.messages;
create policy "message participants" on public.messages
  for select using (
    exists (
      select 1 from public.conversations c
      where c.id = conversation_id
        and (
          c.customer_id = auth.uid()
          or public.is_admin()
          or c.provider_id in (select id from public.provider_profiles where user_id = auth.uid())
        )
    )
  );

drop policy if exists "insert contact inquiries" on public.contact_inquiries;
create policy "insert contact inquiries" on public.contact_inquiries
  for insert with check (true);

drop policy if exists "admin read inquiries" on public.contact_inquiries;
create policy "admin read inquiries" on public.contact_inquiries
  for select using (public.is_admin());

drop policy if exists "public published announcements" on public.announcements;
create policy "public published announcements" on public.announcements
  for select using (is_published = true or public.is_admin());
